﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MVCCRUD.Models
{
    public class Employee
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int EmployeeId { get; set; }
        [Required(ErrorMessage = "Provide FullName"), MaxLength(100)]
        public string FullName { get; set; } = string.Empty;
        [Required(ErrorMessage = "Provide Email"), MaxLength(100)]
        public string Email { get; set; } = string.Empty;
        [Required(ErrorMessage = "Enter HireDate")]
        public DateTime HireDate { get; set; } = DateTime.UtcNow;
        [Required]
        public bool Active { get; set; } = true;
    }
}
