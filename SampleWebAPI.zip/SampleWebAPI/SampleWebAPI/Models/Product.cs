﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SampleWebAPI.Models
{
    public class Product
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required, MaxLength(45)]
        public string Name { get; set; } = string.Empty;
        [Required, DataType(DataType.Currency)]
        [Column(TypeName = "decimal(12, 2)")]
        [DisplayFormat(DataFormatString = "{0:C2}")]
        public decimal Price { get; set; }
        [Required]
        public int Amount { get; set; }
        [Required, MaxLength(100)]
        public string? Description { get; set; } = string.Empty;
        [Required]
        public DateTime CreationDate { get; set; } = DateTime.Now;
    }
}
