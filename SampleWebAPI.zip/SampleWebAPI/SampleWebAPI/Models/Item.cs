﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SampleWebAPI.Models
{
    public class Item
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required, MaxLength(45)]
        public string Name { get; set; } = string.Empty;
        [Required, Range(0, 100)]
        public int Amount { get; set; }
    }
}
