﻿using Microsoft.AspNetCore.Mvc;
using SampleWebAPI.Models;
using System.Data.SqlClient;
using System.Data;

namespace SampleWebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        private readonly string _connectionString;

        public ProductsController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection")!;
        }

        [HttpGet]
        public ActionResult<IEnumerable<Product>> GetProducts()
        {
            List<Product> products = new();
            try
            {
                using (SqlConnection connection = new(_connectionString))
                {
                    using (SqlCommand command = new("GetProducts", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        connection.Open();
                        using SqlDataReader reader = command.ExecuteReader();
                        while (reader.Read())
                        {
                            Product product = new()
                            {
                                Id = Convert.ToInt32(reader[0]),
                                Name = reader.GetString(1),
                                Price = Convert.ToDecimal(reader[2]),
                                Amount = Convert.ToInt32(reader[3]),
                                Description = reader.GetString(4),
                                CreationDate = Convert.ToDateTime(reader[5])
                            };
                            products.Add(product);
                        }
                    }
                }
                return Ok(products);
            }
            catch (Exception ex)
            {
                // Log the exception as necessary
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost]
        public ActionResult InsertProduct(Product product)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                using (SqlConnection connection = new(_connectionString))
                {
                    using (SqlCommand command = new("InsertProduct", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@Name", product.Name);
                        command.Parameters.AddWithValue("@Price", product.Price);
                        command.Parameters.AddWithValue("@Amount", product.Amount);
                        command.Parameters.AddWithValue("@Description", product.Description);
                        connection.Open();
                        command.ExecuteNonQuery();
                    }
                }
                return StatusCode(201); // Created
            }
            catch (Exception ex)
            {
                // Log the exception
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("{id}")]
        public ActionResult UpdateProduct(int id, Product product)
        {
            if (id != product.Id)
            {
                return BadRequest("Product ID mismatch");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                using (SqlConnection connection = new(_connectionString))
                {
                    using (SqlCommand command = new("UpdateProduct", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@Id", product.Id);
                        command.Parameters.AddWithValue("@Name", product.Name);
                        command.Parameters.AddWithValue("@Price", product.Price);
                        command.Parameters.AddWithValue("@Amount", product.Amount);
                        command.Parameters.AddWithValue("@Description", product.Description);
                        connection.Open();
                        command.ExecuteNonQuery();
                    }
                }
                return NoContent(); // Success but no content to return
            }
            catch (Exception ex)
            {
                // Log the exception
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpDelete("{id}")]
        public ActionResult DeleteProduct(int id)
        {
            try
            {
                using (SqlConnection connection = new(_connectionString))
                {
                    using (SqlCommand command = new("DeleteProduct", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@Id", id);
                        connection.Open();
                        command.ExecuteNonQuery();
                    }
                }
                return NoContent(); // Successfully deleted, no content to return
            }
            catch (Exception ex)
            {
                // Log the exception
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
