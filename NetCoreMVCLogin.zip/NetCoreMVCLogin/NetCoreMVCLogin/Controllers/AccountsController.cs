﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using NetCoreMVCLogin.Data;
using NetCoreMVCLogin.Models;
using System.Data;
using System.Data.SqlClient;
using System.Security.Claims;

namespace NetCoreMVCLogin.Controllers
{
    public class AccountsController : Controller
    {
        private readonly AppDbContext _context;

        public AccountsController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Index() => View();

        public IActionResult Login()
        {
            ClaimsPrincipal principal = HttpContext.User;
            if (principal.Identity != null && principal.Identity.IsAuthenticated)
            {
                return RedirectToAction(nameof(Index), "Home");
            }
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(User user)
        {
            if (user == null || string.IsNullOrWhiteSpace(user.Username) || string.IsNullOrWhiteSpace(user.Password))
            {
                ModelState.AddModelError(string.Empty, "Username and Password are required.");
                return View(user);
            }

            try
            {
                using (SqlConnection conn = new(_context.ConnectionString))
                {
                    using (SqlCommand cmd = new("SP_VALIDATE_USER", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Username", user.Username);
                        cmd.Parameters.AddWithValue("@Password", user.Password);
                        conn.Open();
                        using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    // Check if specific values in the reader are null
                                    string username = !reader.IsDBNull(reader.GetOrdinal("Username")) ? reader.GetString(reader.GetOrdinal("Username")) : string.Empty;
                                    string role = !reader.IsDBNull(reader.GetOrdinal("Role")) ? reader.GetString(reader.GetOrdinal("Role")) : "User"; // Example of another field

                                    // You can now create the claims based on these values
                                    ClaimsIdentity identity = new(new[]
                                    {
                                new Claim(ClaimTypes.Name, username),
                                new Claim(ClaimTypes.Role, role) // Example of adding role claim
                            }, CookieAuthenticationDefaults.AuthenticationScheme);

                                    ClaimsPrincipal principal = new(identity);

                                    await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal, new AuthenticationProperties
                                    {
                                        IsPersistent = user.KeepLoggedIn
                                    });

                                    return RedirectToAction(nameof(Index), "Home");
                                }
                            }
                            else
                            {
                                ModelState.AddModelError(string.Empty, "Invalid username or password.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, "An error occurred: " + ex.Message);
            }

            return View(user);
        }
    }
}
