﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NetCoreMVCLogin.Models
{
    public class User
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required(ErrorMessage = "Username required"), MaxLength(45)]
        public string Username { get; set; } = string.Empty;

        [Required(ErrorMessage = "Password required"), MaxLength(255)]
        public string Password { get; set; } = string.Empty;

        [NotMapped]
        public bool KeepLoggedIn { get; set; } = false;
    }
}
