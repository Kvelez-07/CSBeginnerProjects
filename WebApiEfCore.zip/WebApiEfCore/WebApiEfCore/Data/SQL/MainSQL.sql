﻿INSERT INTO Clients (FirstName, LastName, Email, Phone, Address, Status, CreatedAt)
VALUES
('John', 'Doe', 'john@gmail.com', '1234567890', '1234 Main St', 'Active', CURRENT_TIMESTAMP),
('Jane', 'Doe', 'jane@gmail.com', '1234567890', '1234 Main St', 'Active', CURRENT_TIMESTAMP),
('Sam', 'Smith', 'sam@gmail.com', '1234567890', '1234 Main St', 'Active', CURRENT_TIMESTAMP),
('Emily', 'Johnson', 'emily.johnson@gmail.com', '9876543210', '5678 Oak St', 'Active', CURRENT_TIMESTAMP),
('Michael', 'Brown', 'michael.brown@gmail.com', '5554443333', '9876 Pine St', 'Active', CURRENT_TIMESTAMP),
('Sarah', 'Davis', 'sarah.davis@gmail.com', '2223334444', '8765 Maple St', 'Inactive', CURRENT_TIMESTAMP),
('David', 'Wilson', 'david.wilson@gmail.com', '1112223333', '5432 Elm St', 'Active', CURRENT_TIMESTAMP),
('Jessica', 'Miller', 'jessica.miller@gmail.com', '3334445555', '4321 Birch St', 'Active', CURRENT_TIMESTAMP);