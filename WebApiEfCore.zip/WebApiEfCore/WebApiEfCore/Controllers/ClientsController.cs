﻿using Microsoft.AspNetCore.Mvc;
using WebApiEfCore.Data;
using WebApiEfCore.Models;
using WebApiEfCore.Models.DTOs;

namespace WebApiEfCore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public ClientsController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult GetClients()
        {
            var clients = _context.Clients.OrderByDescending(c => c.Id).ToList();

            if (clients == null || clients.Count == 0)
                return NotFound("No clients found.");

            return Ok(clients);
        }

        [HttpGet("{id}")]
        public IActionResult GetClient(int id)
        {
            var client = _context.Clients.Find(id);

            if (client == null)
                return NotFound("Client not found.");

            return Ok(client);
        }

        [HttpPost]
        public IActionResult CreateClient(ClientDTO clientDTO)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var client = new Client
            {
                FirstName = clientDTO.FirstName,
                LastName = clientDTO.LastName,
                Email = clientDTO.Email,
                Phone = clientDTO.Phone,
                Address = clientDTO.Address,
                Status = clientDTO.Status,
                CreatedAt = DateTime.UtcNow
            };

            _context.Clients.Add(client);
            _context.SaveChanges();

            return CreatedAtAction(nameof(GetClient), new { id = client.Id }, client);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateClient(int id, ClientDTO clientDTO)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var client = _context.Clients.Find(id);

            if (client == null)
                return NotFound("Client not found.");

            client.FirstName = clientDTO.FirstName;
            client.LastName = clientDTO.LastName;
            client.Email = clientDTO.Email;
            client.Phone = clientDTO.Phone;
            client.Address = clientDTO.Address;
            client.Status = clientDTO.Status;

            _context.SaveChanges();

            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteClient(int id)
        {
            var client = _context.Clients.Find(id);

            if (client == null)
                return NotFound("Client not found.");

            _context.Clients.Remove(client);
            _context.SaveChanges();

            return NoContent();
        }
    }
}