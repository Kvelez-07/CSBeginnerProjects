﻿using Microsoft.AspNetCore.Mvc;
using SessionsMVC.Models;

namespace SessionsMVC.Controllers
{
    public class StudentsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(AppUser user)
        {
            //if (user.Username == "admin" && user.Password == "admin")
            //{
            //    HttpContext.Session.SetString("username", user.Username);
            //    return RedirectToAction(nameof(Index));
            //}
            //else
            //{
            //    ViewBag.Message = "Invalid username or password";
            //    return View();
            //}
            HttpContext.Session.SetObject("currentUser", user);
            return RedirectToAction(nameof(Index), "Home");
        }
    }
}
