﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using BlazorWebApp.Models;

namespace BlazorWebApp.Data
{
    public class BlazorWebAppIdentityContext(DbContextOptions<BlazorWebAppIdentityContext> options) : IdentityDbContext<BlazorWebAppUser>(options)
    {
        public DbSet<Movie> Movies { get; set; } = default!;
    }
}
