﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BlazorWebApp.Models
{
    public class Movie
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required, MaxLength(45)]
        public string Title { get; set; } = string.Empty;

        [Required]
        public DateOnly ReleaseDate { get; set; }

        [Required, MaxLength(30)]
        public string Genre { get; set; } = string.Empty;

        [Required, Range(0, 100)]
        [DataType(DataType.Currency)]
        [Column(TypeName = "decimal(5, 2)")]
        [Display(Name = "Price ($)")]
        [DisplayFormat(DataFormatString = "{0:C2}")]
        public decimal Price { get; set; }
    }
}
