﻿using Microsoft.AspNetCore.Mvc;
using MultiPurposeMVC.Models;

namespace MultiPurposeMVC.Controllers
{
    public class MPGController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            // No need to set initial values in ViewBag for form fields
            return View();
        }

        [HttpPost]
        public IActionResult Index(MPG driveStats)
        {
            if (ModelState.IsValid)
            {
                ViewBag.MPG = driveStats.CalculateMPG();
                return View(driveStats);
            }
            else
            {
                ViewData["Error"] = "Invalid input. Please try again.";
                return View(driveStats);
            }
        }
    }
}
