﻿using Microsoft.AspNetCore.Mvc;
using MultiPurposeMVC.Models;

namespace MultiPurposeMVC.Controllers
{
    public class BMIController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            // Simply return the view, no need to set initial values in ViewBag
            return View();
        }

        [HttpPost]
        public IActionResult Index(BMI bmi)
        {
            if (ModelState.IsValid)
            {
                ViewBag.BMI = bmi.CalculateBMI();
                ViewBag.BMICategory = bmi.GetBMICategory();
                return View(bmi);
            }
            else
            {
                ViewData["Error"] = "Invalid input. Please try again.";
                return View();
            }
        }
    }
}
