﻿using Microsoft.AspNetCore.Mvc;
using MultiPurposeMVC.Data;
using MultiPurposeMVC.Models;

namespace MultiPurposeMVC.Controllers
{
    public class RegisterController : Controller
    {
        private readonly AppDbContext _context;

        public RegisterController(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index() => await Task.Run(() => View());

        [HttpPost]
        public async Task<IActionResult> Index(Customer customer)
        {
            if (ModelState.IsValid)
            {
                _context.Add(customer);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(customer);
        }
    }
}
