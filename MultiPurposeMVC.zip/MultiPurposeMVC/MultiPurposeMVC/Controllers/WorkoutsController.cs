﻿using Microsoft.AspNetCore.Mvc;
using MultiPurposeMVC.Data;
using MultiPurposeMVC.Models;

namespace MultiPurposeMVC.Controllers
{
    public class WorkoutsController : Controller
    {
        private readonly AppDbContext _context;

        public WorkoutsController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> Details(int id)
        {
            var workout = await _context.WorkoutLogs.FindAsync(id);
            if (workout == null) return NotFound();
            return View(workout);
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var workout = await _context.WorkoutLogs.FindAsync(id);
            if (workout == null) return NotFound();
            return View(workout);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, WorkoutLog workoutUpdate)
        {
            if (id != workoutUpdate.WorkoutLogId) return BadRequest();

            if (!ModelState.IsValid) return View(workoutUpdate);

            var workout = await _context.WorkoutLogs.FindAsync(id);
            if (workout == null) return NotFound();

            workout.Date = workoutUpdate.Date;
            workout.DurationInMinutes = workoutUpdate.DurationInMinutes;
            workout.CaloriesBurnt = workoutUpdate.CaloriesBurnt;

            _context.Update(workout);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Details), new { id = workout.UserId });
        }

        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            var workout = await _context.WorkoutLogs.FindAsync(id);
            if (workout == null) return NotFound();

            _context.WorkoutLogs.Remove(workout);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Details), new { id = workout.UserId });
        }
    }
}
