﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MultiPurposeMVC.Models
{
    public class WorkoutLog
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int WorkoutLogId { get; set; }
        [Required]
        public DateTime Date { get; set; } = DateTime.UtcNow;
        [Required]
        public int DurationInMinutes { get; set; }
        [Required]
        public double CaloriesBurnt { get; set; }
        [Required]
        public int UserId { get; set; }
        [Required, ValidateNever]
        public User User { get; set; } = null!; // Navigation property N : 1
    }
}