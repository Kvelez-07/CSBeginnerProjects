﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MultiPurposeMVC.Models
{
    public class Activity
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required(ErrorMessage = "Enter activiy name")]
        public string Name { get; set; } = string.Empty;
        [Required]
        public int TripId { get; set; }
        public Trip? Trip { get; set; } = new(); // Navigation property
    }
}
