﻿using System.ComponentModel.DataAnnotations;

namespace MultiPurposeMVC.Models
{
    public class BMI
    {
        private double _weight;
        private double _height;

        [Required(ErrorMessage = "Please enter your weight.")]
        [Range(1, double.MaxValue, ErrorMessage = "Please enter a positive number.")]
        public double Weight
        {
            get => _weight;
            set => _weight = value;
        }

        [Required(ErrorMessage = "Please enter your height.")]
        [Range(1, double.MaxValue, ErrorMessage = "Please enter a positive number.")]
        public double Height
        {
            get => _height;
            set => _height = value;
        }

        public double CalculateBMI() => _weight / (_height * _height);

        public string GetBMICategory()
        {
            double _bmi = CalculateBMI();
            if (_bmi < 18.5)
            {
                return "Underweight";
            }
            else if (_bmi >= 18.5 && _bmi < 24.9)
            {
                return "Normal weight";
            }
            else if (_bmi >= 25 && _bmi < 29.9)
            {
                return "Overweight";
            }
            else
            {
                return "Obesity";
            }
        }
    }
}
