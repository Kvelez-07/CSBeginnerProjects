﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MultiPurposeMVC.Models
{
    public class Customer
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [MinimumAge(18, ErrorMessage = "You must be at least 18 years old.")]
        [Required(ErrorMessage = "Enter username"), MaxLength(45)]
        [RegularExpression(@"^[a-zA-Z''-'\s]{1,40}$", ErrorMessage = "Characters are not allowed.")]
        public string Username { get; set; } = string.Empty;

        [Required(ErrorMessage = "Enter email"), Display(Name = "Email Address")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Enter BirthDate"), Display(Name = "Date of Birth")]
        public DateTime BirthDate { get; set; } = DateTime.Now;

        [Required(ErrorMessage = "Enter password"), DataType(DataType.Password)]
        [StringLength(100, ErrorMessage = "Password must be at least 6 characters long.", MinimumLength = 6)]
        public string Password { get; set; } = string.Empty;

        [NotMapped] // Does not effect with your database
        [Required(ErrorMessage = "Enter confirm password"), DataType(DataType.Password)]
        [Compare(nameof(Password), ErrorMessage = "Password and Confirm Password must match.")]
        [StringLength(100, ErrorMessage = "Password must be at least 6 characters long.", MinimumLength = 6)]
        public string ConfirmPassword { get; set; } = string.Empty;
    }
}
