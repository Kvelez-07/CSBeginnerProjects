﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MultiPurposeMVC.Models
{
    public class Trip
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required(ErrorMessage = "Enter destination")]
        public string Destination { get; set; } = string.Empty;
        [Required(ErrorMessage = "Enter accomodation")]
        public string Accomodation { get; set; } = string.Empty;
        [Required(ErrorMessage = "Enter start date")]
        public DateTime StartDate { get; set; } = DateTime.UtcNow;
        [Required(ErrorMessage = "Enter end date")]
        public DateTime EndDate { get; set; } = DateTime.UtcNow;
        [Required(ErrorMessage = "Enter accomodation phone")]
        public string AccomodationPhone { get; set; } = string.Empty;
        [Required(ErrorMessage = "Enter accomodation email")]
        public string AccomodationEmail { get; set; } = string.Empty;
        [Required]
        public List<Activity> Activities { get; set; } = new();

        public bool IsEndDateAfterStartDate()
        {
            return EndDate > StartDate;
        }
    }
}
