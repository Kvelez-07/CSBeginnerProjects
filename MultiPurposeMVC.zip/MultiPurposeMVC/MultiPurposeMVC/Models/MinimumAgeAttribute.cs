﻿using System.ComponentModel.DataAnnotations;

namespace MultiPurposeMVC.Models
{
    public class MinimumAgeAttribute : ValidationAttribute
    {
        private int minYears;

        public MinimumAgeAttribute(int years)
        {
            minYears = years;
        }

        protected override ValidationResult IsValid(object? value, ValidationContext validationContext)
        {
            if (value != null)
            {
                var birthDate = (DateTime)value;
                if (birthDate.AddYears(minYears) > DateTime.Now)
                {
                    return new ValidationResult($"You must be at least {minYears} years old to register.");
                }
            }
            return ValidationResult.Success!;
        }
    }
}
