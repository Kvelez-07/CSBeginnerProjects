﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MultiPurposeMVC.Models
{
    public class User
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int UserId { get; set; }
        [Required, MaxLength(45)]
        public string FirstName { get; set; } = null!;
        [Required, MaxLength(45)]
        public string LastName { get; set; } = null!;
        [Required]
        public int Age { get; set; }
        [Required, DataType(DataType.Currency)]
        [Column(TypeName = "decimal(18, 2)")]
        [DisplayFormat(DataFormatString = "{0:C}", ApplyFormatInEditMode = true)]
        public decimal Salary { get; set; }
        [Required]
        public List<WorkoutLog> Workouts { get; set; } = null!; // Navigation property 1 : N
    }
}
