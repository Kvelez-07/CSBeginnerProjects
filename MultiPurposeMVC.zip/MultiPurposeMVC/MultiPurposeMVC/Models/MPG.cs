﻿using System.ComponentModel.DataAnnotations;

namespace MultiPurposeMVC.Models
{
    public class MPG
    {
        private double? _milesDriven;
        private double? _gallonsUsed;

        [Required(ErrorMessage = "Please enter the number of miles driven.")]
        [Range(1, double.MaxValue, ErrorMessage = "Please enter a positive number.")]
        public double? MilesDriven
        {
            get => _milesDriven;
            set => _milesDriven = value;
        }

        [Required(ErrorMessage = "Please enter the number of gallons used.")]
        [Range(1, double.MaxValue, ErrorMessage = "Please enter a positive number.")]
        public double? GallonsUsed
        {
            get => _gallonsUsed;
            set => _gallonsUsed = value;
        }

        public double? CalculateMPG() => MilesDriven / GallonsUsed;
    }
}
