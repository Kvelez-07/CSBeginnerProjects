﻿namespace MultiPurposeMVC.Models.ViewModel
{
    public class UserVM
    {
        public List<User> Users { get; set; } = new();
    }
}
