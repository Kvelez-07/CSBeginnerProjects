﻿namespace MultiPurposeMVC.Models.ViewModel
{
    public class UserWorkoutVM
    {
        public User User { get; set; } = new();
        public List<WorkoutLog> Workouts { get; set; } = new();
    }
}
