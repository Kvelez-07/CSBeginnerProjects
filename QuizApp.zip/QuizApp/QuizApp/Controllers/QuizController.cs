﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using QuizApp.Data;
using QuizApp.Models.ViewModels;

namespace QuizApp.Controllers
{
    public class QuizController : Controller
    {
        private readonly ApplicationDbContext _dbContext;
        public QuizController(ApplicationDbContext dbContext) => _dbContext = dbContext;

        [HttpGet]
        public IActionResult Index()
        {
            var questions = _dbContext.Questions.Include(q => q.Options)
                .Select(x => new QuestionItem()
                {
                    Id = x.Id,
                    Text = x.Text,
                    // Fixed: Use o.Text for option text and o.Id for option value
                    Options = x.Options.Select(o => new SelectListItem(o.Text, o.Id.ToString())).ToList()
                }).ToList();
            return View(new QuizViewModel { Questions = questions });
        }

        [HttpPost]
        public IActionResult Answer(List<Guid> userAnswers)
        {
            var questions = _dbContext.Questions.ToList();
            var score = 0;
            var totalScore = questions.Count;

            for (var i = 0; i < userAnswers.Count; i++)
            {
                if (questions[i].CorrectOption == userAnswers[i])
                    score++;
            }

            ViewBag.Score = score;
            ViewBag.TotalScore = totalScore;
            return View(nameof(Results));
        }

        [HttpGet]
        public IActionResult Results() => View();
    }
}