using Microsoft.EntityFrameworkCore;
using QuizApp.Data;
using QuizApp.Models.Entities;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// AppDbContext configuration
builder.Services.AddDbContext<ApplicationDbContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var dbContext = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

    if (!dbContext.Questions.Any())
    {
        var questions = new List<Question>();

        // Question 1
        var q1OptionId = Guid.NewGuid();
        var q1Id = Guid.NewGuid();
        questions.Add(new Question
        {
            Id = q1Id,
            Text = "What is the capital of France?",
            Options = new List<Option>
            {
                new() { Id = Guid.NewGuid(), Text = "Berlin", QuestionId = q1Id },
                new() { Id = Guid.NewGuid(), Text = "Madrid", QuestionId = q1Id },
                new() { Id = q1OptionId, Text = "Paris", QuestionId = q1Id },
                new() { Id = Guid.NewGuid(), Text = "Rome", QuestionId = q1Id }
            },
            CorrectOption = q1OptionId
        });

        // Question 2
        var q2OptionId = Guid.NewGuid();
        var q2Id = Guid.NewGuid();
        questions.Add(new Question
        {
            Id = q2Id,
            Text = "Which planet is known as the Red Planet?",
            Options = new List<Option>
            {
                new() { Id = Guid.NewGuid(), Text = "Earth", QuestionId = q2Id },
                new() { Id = q2OptionId, Text = "Mars", QuestionId = q2Id },
                new() { Id = Guid.NewGuid(), Text = "Jupiter", QuestionId = q2Id },
                new() { Id = Guid.NewGuid(), Text = "Venus", QuestionId = q2Id }
            },
            CorrectOption = q2OptionId
        });

        // Question 3
        var q3OptionId = Guid.NewGuid();
        var q3Id = Guid.NewGuid();
        questions.Add(new Question
        {
            Id = q3Id,
            Text = "What is the largest ocean on Earth?",
            Options = new List<Option>
            {
                new() { Id = Guid.NewGuid(), Text = "Atlantic Ocean", QuestionId = q3Id },
                new() { Id = Guid.NewGuid(), Text = "Indian Ocean", QuestionId = q3Id },
                new() { Id = q3OptionId, Text = "Pacific Ocean", QuestionId = q3Id },
                new() { Id = Guid.NewGuid(), Text = "Arctic Ocean", QuestionId = q3Id }
            },
            CorrectOption = q3OptionId
        });

        // Question 4
        var q4OptionId = Guid.NewGuid();
        var q4Id = Guid.NewGuid();
        questions.Add(new Question
        {
            Id = q4Id,
            Text = "Who wrote 'Romeo and Juliet'?",
            Options = new List<Option>
            {
                new() { Id = q4OptionId, Text = "William Shakespeare", QuestionId = q4Id },
                new() { Id = Guid.NewGuid(), Text = "Charles Dickens", QuestionId = q4Id },
                new() { Id = Guid.NewGuid(), Text = "Jane Austen", QuestionId = q4Id },
                new() { Id = Guid.NewGuid(), Text = "Mark Twain", QuestionId = q4Id }
            },
            CorrectOption = q4OptionId
        });

        // Question 5
        var q5OptionId = Guid.NewGuid();
        var q5Id = Guid.NewGuid();
        questions.Add(new Question
        {
            Id = q5Id,
            Text = "What is the chemical symbol for water?",
            Options = new List<Option>
            {
                new() { Id = Guid.NewGuid(), Text = "O2", QuestionId = q5Id },
                new() { Id = q5OptionId, Text = "H2O", QuestionId = q5Id },
                new() { Id = Guid.NewGuid(), Text = "CO2", QuestionId = q5Id },
                new() { Id = Guid.NewGuid(), Text = "NaCl", QuestionId = q5Id }
            },
            CorrectOption = q5OptionId
        });

        // Question 6
        var q6OptionId = Guid.NewGuid();
        var q6Id = Guid.NewGuid();
        questions.Add(new Question
        {
            Id = q6Id,
            Text = "Which language is primarily spoken in Brazil?",
            Options = new List<Option>
            {
                new() { Id = Guid.NewGuid(), Text = "Spanish", QuestionId = q6Id },
                new() { Id = Guid.NewGuid(), Text = "French", QuestionId = q6Id },
                new() { Id = q6OptionId, Text = "Portuguese", QuestionId = q6Id },
                new() { Id = Guid.NewGuid(), Text = "English", QuestionId = q6Id }
            },
            CorrectOption = q6OptionId
        });

        dbContext.Questions.AddRange(questions);
        dbContext.SaveChanges();
    }
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseRouting();

app.UseAuthorization();

app.MapStaticAssets();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Quiz}/{action=Index}/{id?}")
    .WithStaticAssets();

app.Run();
