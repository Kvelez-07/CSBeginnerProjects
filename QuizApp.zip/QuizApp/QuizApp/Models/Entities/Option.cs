﻿namespace QuizApp.Models.Entities
{
    public class Option
    {
        public Guid Id { get; init; }

        public required string Text { get; init; } = string.Empty;

        // Question Foreign Key
        public Guid QuestionId { get; init; }
    }
}
