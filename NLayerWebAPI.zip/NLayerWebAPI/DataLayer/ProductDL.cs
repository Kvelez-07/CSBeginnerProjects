﻿using DataLayer.Entities;
using Microsoft.Data.SqlClient;

namespace DataLayer
{
    public class ProductDL
    {
        private readonly string _connectionString;

        public ProductDL(string connectionString) => _connectionString = connectionString;

        public List<Product> GetAll()
        {
            // ADO.NET code to retrieve all products from the database
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand("SELECT * FROM Products", connection);
                using (var reader = command.ExecuteReader())
                {
                    var products = new List<Product>();
                    while (reader.Read())
                    {
                        var product = new Product
                        {
                            Id = reader.GetInt32(0),
                            ProductName = reader.GetString(1),
                            Price = reader.GetInt32(2)
                        };
                        products.Add(product);
                    }
                    return products;
                }
            }
        }
    }
}
