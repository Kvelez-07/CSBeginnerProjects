﻿using BusinessLayer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace PresentationLayer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly ProductBL _productBL;
        public ProductsController(ProductBL productBL) => _productBL = productBL;

        [HttpGet]
        public IActionResult GetAll() => Ok(_productBL.GetAll());
    }
}
