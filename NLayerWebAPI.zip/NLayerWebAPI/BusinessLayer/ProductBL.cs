﻿using DataLayer;
using DataLayer.Entities;

namespace BusinessLayer
{
    public class ProductBL
    {
        private readonly ProductDL _productDL;
        public ProductBL(ProductDL productDL) => _productDL = productDL;

        public List<Product> GetAll() => _productDL.GetAll();
    }
}
