var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Register the TodoItemRepository as a singleton service
builder.Services.AddSingleton<TodoItemRepository>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapGet("/todos", (TodoItemRepository repository) => Results.Ok(repository.GetAll()));
app.MapGet("/todos/{id}", (TodoItemRepository repository, int id) =>
{
    var item = repository.GetById(id);
    return item != null ? Results.Ok(item) : Results.NotFound();
});
app.MapPost("/todos", (TodoItemRepository repository, TodoItem item) =>
{
    repository.Add(item);
    return Results.Created($"/todos/{item.id}", item);
});
app.MapPut("/todos/{id}", (TodoItemRepository repository, int id, TodoItem item) =>
{
    var existingItem = repository.GetById(id);
    if (existingItem == null)
    {
        return Results.NotFound();
    }

    repository.Update(item);
    return Results.NoContent();
});
app.MapDelete("/todos/{id}", (TodoItemRepository repository, int id) =>
{
    if (repository.GetById(id) == null)
    {
        return Results.NotFound();
    }

    repository.Delete(id);
    return Results.NoContent();
});

app.UseHttpsRedirection();

app.Run();

record TodoItem(int id, string title, bool completed);

class TodoItemRepository
{
    private readonly Dictionary<int, TodoItem> _items = new();

    public TodoItemRepository()
    {
        _items.Add(1, new TodoItem(1, "Learn C#", false));
        _items.Add(2, new TodoItem(2, "Learn Blazor", false));
        _items.Add(3, new TodoItem(3, "Learn ASP.NET Core", false));
    }

    public IEnumerable<TodoItem> GetAll() => _items.Values;
    public TodoItem? GetById(int id) => _items.TryGetValue(id, out var item) ? item : null;
    public void Add(TodoItem item) => _items.Add(item.id, item);
    public void Update(TodoItem item) => _items[item.id] = item;
    public void Delete(int id) => _items.Remove(id);
}
