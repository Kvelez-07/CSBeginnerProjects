﻿using LoginApp.Data;
using LoginApp.Models;
using LoginApp.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace LoginApp.Controllers
{
    public class AccessController : Controller
    {
        private AppDbContext _context;

        public AccessController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(RegisterAppUserVM model)
        {
            if (model.Password != model.ConfirmPassword)
            {
                ViewData["Message"] = "The password and confirmation password do not match.";
                ModelState.AddModelError("ConfirmPassword", "The password and confirmation password do not match.");
                return View(model);
            }

            var user = new ApplicationUser
            {
                FullName = model.FullName,
                Email = model.Email,
                Password = model.Password
            };

            await _context.ApplicationUsers.AddAsync(user);
            await _context.SaveChangesAsync();

            if (user.Id.ToString() != string.Empty)
            {
                return RedirectToAction(nameof(Login));
            }

            ViewData["Message"] = "An error occurred while registering the user.";
            return View();
        }

        public IActionResult Login()
        {
            if (User.Identity!.IsAuthenticated)
            {
                return RedirectToAction(nameof(Index), "Home");
            }
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginAppUserVM model)
        {
            var user = await _context.ApplicationUsers.FirstOrDefaultAsync(u => u.Email == model.Email && u.Password == model.Password);

            if (user == null)
            {
                ViewData["Message"] = "Invalid email or password.";
                return View(model);
            }

            // Create a list of claims
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, user.FullName)
            };

            // Create a ClaimsIdentity object and set the authentication scheme
            var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var authProperties = new AuthenticationProperties()
            {
                AllowRefresh = true,
            };

            // Sign in the user
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity), authProperties);
            return RedirectToAction(nameof(Index), "Home"); // Redirect to the home page
        }
    }
}
