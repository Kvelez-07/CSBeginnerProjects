﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using RegisterMVC.Models;
using System.Data;

namespace RegisterMVC.Controllers
{
    public class AppUsersController : Controller
    {
        private readonly IConfiguration _configuration;

        public AppUsersController(IConfiguration configuration) => _configuration = configuration;

        [HttpGet]
        public IActionResult Index()
        {
            using (SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                using (SqlCommand cmd = new SqlCommand("SP_GET_ALL_USERS", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        List<AppUser> users = new();
                        while (reader.Read())
                        {
                            users.Add(new AppUser
                            {
                                Id = reader.GetInt32(0),
                                Username = reader.GetString(1),
                                Age = reader.GetInt32(2),
                                Email = reader.GetString(3)
                            });
                        }
                        return View(users);
                    }
                }
            }
        }

        [HttpGet]
        public IActionResult Register() => View();

        [HttpPost]
        public IActionResult Register(AppUser user)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_REGISTER", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Username", user.Username);
                        cmd.Parameters.AddWithValue("@Age", user.Age);
                        cmd.Parameters.AddWithValue("@Email", user.Email);

                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();
                    }
                }

                return RedirectToAction(nameof(Index));
            }
            catch (SqlException ex)
            {
                ModelState.AddModelError($"{ex.Message}\n", "An error occurred while registering the user.");
                return View(user);
            }
        }

        // GET: AppUsers/Details/5
        [HttpGet]
        public IActionResult Details(int id)
        {
            AppUser user = GetUserById(id);
            if (user == null) return NotFound();
            return View(user);
        }

        // GET: AppUsers/Edit/5
        [HttpGet]
        public IActionResult Edit(int id)
        {
            AppUser user = GetUserById(id);
            if (user == null) return NotFound();
            return View(user);
        }

        [HttpPost]
        public IActionResult Edit(AppUser user)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_UPDATE_USER", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Id", user.Id);
                        cmd.Parameters.AddWithValue("@Username", user.Username);
                        cmd.Parameters.AddWithValue("@Age", user.Age);
                        cmd.Parameters.AddWithValue("@Email", user.Email);

                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();
                    }
                }

                return RedirectToAction(nameof(Index));
            }
            catch (SqlException ex)
            {
                ModelState.AddModelError($"{ex.Message}\n", "An error occurred while updating the user.");
                return View(user);
            }
        }

        // GET: AppUsers/Delete/5
        [HttpGet]
        public IActionResult Delete(int id)
        {
            AppUser user = GetUserById(id);
            if (user == null) return NotFound();
            return View(user);
        }

        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_DELETE_USER", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Id", id);

                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();
                    }
                }

                return RedirectToAction(nameof(Index));
            }
            catch (SqlException ex)
            {
                ModelState.AddModelError($"{ex.Message}\n", "An error occurred while deleting the user.");
                return View();
            }
        }

        private AppUser GetUserById(int id)
        {
            using (SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                using (SqlCommand cmd = new SqlCommand("SP_GET_USER_BY_ID", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Id", id);

                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new AppUser
                            {
                                Id = reader.GetInt32(0),
                                Username = reader.GetString(1),
                                Age = reader.GetInt32(2),
                                Email = reader.GetString(3)
                            };
                        }
                    }
                }
            }
            return null!;
        }
    }
}
