IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Users')
BEGIN
	DROP TABLE dbo.Users;
END;
GO

-- Create the Users table first
CREATE TABLE Users (
    Id INT NOT NULL IDENTITY(1,1),
    Username NVARCHAR(45) NOT NULL,
    Age INT NOT NULL,
    Email NVARCHAR(100) NOT NULL
);
GO

-- Create the SP_REGISTER procedure
CREATE OR ALTER PROCEDURE SP_REGISTER
(
    @Username NVARCHAR(45),
    @Age INT,
    @Email NVARCHAR(100)
)
AS
BEGIN
    BEGIN TRY
        INSERT INTO Users (Username, Age, Email)
        VALUES (@Username, @Age, @Email);
    END TRY
    BEGIN CATCH
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;
        SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH;
END;
GO

-- Create the SP_GET_ALL_USERS procedure
CREATE OR ALTER PROCEDURE SP_GET_ALL_USERS
AS
BEGIN
    BEGIN TRY
        SELECT * FROM Users;
    END TRY
    BEGIN CATCH
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;
        SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE SP_GET_USER_BY_ID
(
    @Id INT
)
AS
BEGIN
    BEGIN TRY
        SELECT Id, Username, Age, Email
        FROM Users
        WHERE Id = @Id;
    END TRY
    BEGIN CATCH
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;
        SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE SP_UPDATE_USER
(
    @Id INT,
    @Username NVARCHAR(45),
    @Age INT,
    @Email NVARCHAR(100)
)
AS
BEGIN
    BEGIN TRY
        UPDATE Users
        SET Username = @Username,
            Age = @Age,
            Email = @Email
        WHERE Id = @Id;
    END TRY
    BEGIN CATCH
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;
        SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE SP_DELETE_USER
(
    @Id INT
)
AS
BEGIN
    BEGIN TRY
        DELETE FROM Users
        WHERE Id = @Id;
    END TRY
    BEGIN CATCH
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;
        SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH;
END;
GO
