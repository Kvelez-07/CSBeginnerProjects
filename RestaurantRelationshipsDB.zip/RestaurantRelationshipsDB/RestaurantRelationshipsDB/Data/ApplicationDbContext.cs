﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using RestaurantRelationshipsDB.Models;

namespace RestaurantRelationshipsDB.Data
{
    public class ApplicationDbContext : IdentityDbContext<AppUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> Items { get; set; }
        public DbSet<Ingredient> Ingredients { get; set; }
        public DbSet<ProductIngredient> ProductIngredients { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Category>().HasData(
                new Category { CategoryId = 1, Name = "Appetizers" },
                new Category { CategoryId = 2, Name = "Entrees" },
                new Category { CategoryId = 3, Name = "Desserts" },
                new Category { CategoryId = 4, Name = "Drinks" },
                new Category { CategoryId = 5, Name = "Sides" },
                new Category { CategoryId = 6, Name = "Salads" }
            );

            modelBuilder.Entity<Ingredient>().HasData(
                new Ingredient { IngredientId = 1, Name = "Flour" },
                new Ingredient { IngredientId = 2, Name = "Sugar" },
                new Ingredient { IngredientId = 3, Name = "Salt" },
                new Ingredient { IngredientId = 4, Name = "Pepper" },
                new Ingredient { IngredientId = 5, Name = "Eggs" },
                new Ingredient { IngredientId = 6, Name = "Milk" }
            );

            modelBuilder.Entity<Product>().HasData(
                new Product { ProductId = 1, Name = "French Fries", Price = 2.99m, CategoryId = 5, Description = "Delicious" },
                new Product { ProductId = 2, Name = "Cheeseburger", Price = 5.99m, CategoryId = 2, Description = "Delicious" },
                new Product { ProductId = 3, Name = "Coke", Price = 1.99m, CategoryId = 4, Description = "Delicious" }
            );

            modelBuilder.Entity<ProductIngredient>().HasData(
                new ProductIngredient { ProductIngredientId = 1, ProductId = 1, IngredientId = 1 },
                new ProductIngredient { ProductIngredientId = 2, ProductId = 1, IngredientId = 3 },
                new ProductIngredient { ProductIngredientId = 3, ProductId = 2, IngredientId = 1 },
                new ProductIngredient { ProductIngredientId = 4, ProductId = 2, IngredientId = 3 },
                new ProductIngredient { ProductIngredientId = 5, ProductId = 2, IngredientId = 4 },
                new ProductIngredient { ProductIngredientId = 6, ProductId = 2, IngredientId = 5 },
                new ProductIngredient { ProductIngredientId = 7, ProductId = 2, IngredientId = 6 },
                new ProductIngredient { ProductIngredientId = 8, ProductId = 3, IngredientId = 3 }
            );
        }
    }
}
