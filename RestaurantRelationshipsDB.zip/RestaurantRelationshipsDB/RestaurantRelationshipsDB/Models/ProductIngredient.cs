﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RestaurantRelationshipsDB.Models
{
    public class ProductIngredient
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ProductIngredientId { get; set; }

        [Required]
        public int ProductId { get; set; }

        public virtual Product Product { get; set; } = null!;

        [Required]
        public int IngredientId { get; set; }

        public virtual Ingredient Ingredient { get; set; } = null!;
    }
}
