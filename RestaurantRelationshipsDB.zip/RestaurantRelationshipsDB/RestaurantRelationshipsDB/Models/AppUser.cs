﻿using Microsoft.AspNetCore.Identity;

namespace RestaurantRelationshipsDB.Models
{
    public class AppUser : IdentityUser
    {
        public ICollection<Order> Orders { get; set; } = null!;
    }
}
