﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApiEFCoreNet8.Models
{
    public class Employee
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required(ErrorMessage = "Enter Full Name"), StringLength(100, MinimumLength =6, ErrorMessage = "Enter at least 6 chars"), MaxLength(50), Display(Name = "Name")]
        public string FullName { get; set; } = string.Empty;
        [Required, Column(TypeName = "decimal(18, 2)")]
        [DisplayFormat(DataFormatString = "{0:C2}")]
        [DataType(DataType.Currency)]
        public decimal Salary { get; set; }
        [Required]
        public int ProfileId { get; set; }
        public Profile Profile { get; set; } = new();
    }
}
