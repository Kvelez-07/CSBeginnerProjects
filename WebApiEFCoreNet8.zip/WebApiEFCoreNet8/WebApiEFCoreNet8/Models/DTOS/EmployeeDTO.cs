﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace WebApiEFCoreNet8.Models.DTOS
{
    public class EmployeeDTO
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required(ErrorMessage = "Enter Full Name"), StringLength(100, MinimumLength = 6, ErrorMessage = "Enter at least 6 chars"), MaxLength(50), Display(Name = "Name")]
        public string FullName { get; set; } = string.Empty;
        [Required, Column(TypeName = "decimal(18, 2)")]
        [DisplayFormat(DataFormatString = "{0:C2}")]
        [DataType(DataType.Currency)]
        public decimal Salary { get; set; }
    }
}
