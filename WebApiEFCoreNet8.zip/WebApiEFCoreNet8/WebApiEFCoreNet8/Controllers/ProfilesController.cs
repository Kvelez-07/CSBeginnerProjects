﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApiEFCoreNet8.Data;
using WebApiEFCoreNet8.Models;
using WebApiEFCoreNet8.Models.DTOS;

namespace WebApiEFCoreNet8.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProfilesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public ProfilesController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet("GetProfiles")]
        public async Task<ActionResult<IEnumerable<ProfileDTO>>> GetProfiles()
        {
            return await _context.Profiles
                .Select(profile => new ProfileDTO
                {
                    Id = profile.Id,
                    Name = profile.Name
                })
                .ToListAsync();
        }

        [HttpGet("GetProfileBy/{id}")]
        public async Task<ActionResult<ProfileDTO>> GetProfile(int id)
        {
            var profile = await _context.Profiles
                .Select(profile => new ProfileDTO
                {
                    Id = profile.Id,
                    Name = profile.Name
                })
                .FirstOrDefaultAsync(profile => profile.Id == id);

            if (profile == null) return NotFound();
            return profile;
        }

        [HttpPost("SaveProfile")]
        public async Task<ActionResult<ProfileDTO>> SaveProfile(ProfileDTO profileDTO)
        {
            var profile = new Profile
            {
                Name = profileDTO.Name
            };

            _context.Profiles.Add(profile);
            await _context.SaveChangesAsync();
            return CreatedAtAction("GetProfile", new { id = profile.Id }, profile);
        }

        [HttpPut("UpdateProfile/{id}")]
        public async Task<IActionResult> UpdateProfile(int id, ProfileDTO profileDTO)
        {
            if (id != profileDTO.Id) return BadRequest();

            var profile = new Profile
            {
                Id = profileDTO.Id,
                Name = profileDTO.Name
            };

            _context.Entry(profile).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ProfileExists(id)) return NotFound();
                else throw;
            }

            return NoContent();
        }

        private bool ProfileExists(int id)
        {
            return _context.Profiles.Any(profile => profile.Id == id);
        }

        [HttpDelete("DeleteProfile/{id}")]
        public async Task<IActionResult> DeleteProfile(int id)
        {
            var profile = await _context.Profiles.FindAsync(id);
            if (profile == null) return NotFound();

            _context.Profiles.Remove(profile);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
