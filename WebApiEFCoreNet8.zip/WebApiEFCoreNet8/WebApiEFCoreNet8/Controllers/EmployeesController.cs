﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApiEFCoreNet8.Data;
using WebApiEFCoreNet8.Models;
using WebApiEFCoreNet8.Models.DTOS;

namespace WebApiEFCoreNet8.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {

        private readonly AppDbContext _context;

        public EmployeesController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet("GetEmployees")]
        public async Task<ActionResult<IEnumerable<EmployeeDTO>>> GetEmployees()
        {
            return await _context.Employees
                .Select(employee => new EmployeeDTO
                {
                    Id = employee.Id,
                    FullName = employee.FullName,
                    Salary = employee.Salary
                })
                .ToListAsync();
        }

        [HttpGet("GetEmployeeBy/{id}")]
        public async Task<ActionResult<EmployeeDTO>> GetEmployeeById(int id)
        {
            var employee = await _context.Employees
                .Select(employee => new EmployeeDTO
                {
                    Id = employee.Id,
                    FullName = employee.FullName,
                    Salary = employee.Salary
                })
                .FirstOrDefaultAsync(employee => employee.Id == id);

            if (employee == null) return NotFound();
            return employee;
        }

        [HttpPost("SaveEmployee")]
        public async Task<ActionResult<EmployeeDTO>> SaveEmployee(EmployeeDTO employeeDTO)
        {
            var employee = new Employee
            {
                FullName = employeeDTO.FullName,
                Salary = employeeDTO.Salary
            };

            _context.Employees.Add(employee);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetEmployeeById), new { id = employee.Id }, employeeDTO);
        }

        [HttpPut("UpdateEmployee/{id}")]
        public async Task<IActionResult> UpdateEmployee(int id, EmployeeDTO employeeDTO)
        {
            if (id != employeeDTO.Id) return BadRequest();

            var employee = await _context.Employees.FindAsync(id);
            if (employee == null) return NotFound();

            employee.FullName = employeeDTO.FullName;
            employee.Salary = employeeDTO.Salary;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException) when (!EmployeeExists(id))
            {
                return NotFound();
            }

            return NoContent();
        }

        private bool EmployeeExists(int id)
        {
            return _context.Employees.Any(e => e.Id == id);
        }

        [HttpDelete("DeleteEmployee/{id}")]
        public async Task<ActionResult<EmployeeDTO>> DeleteEmployee(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee == null) return NotFound();

            _context.Employees.Remove(employee);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
