﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RelationshipsAPI.Data;
using RelationshipsAPI.DTO;
using RelationshipsAPI.Models;

namespace RelationshipsAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TlouController : ControllerBase
    {
        private readonly AppDbContext _context;

        public TlouController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<ActionResult<List<Character>>> CreateCharacter(CharacterCreateDTO characterCreateDTO)
        {
            var newCharacter = new Character
            {
                Name = characterCreateDTO.Name,
            };

            var newBackpack = new Backpack
            {
                Description = characterCreateDTO.Backpack.Description,
                Character = newCharacter
            };

            newCharacter.Backpack = newBackpack;

            _context.Characters.Add(newCharacter);
            await _context.SaveChangesAsync();

            // Updated to include Backpack entity
            return Ok(await _context.Characters.Include(c => c.Backpack).ToListAsync());
        }
    }
}