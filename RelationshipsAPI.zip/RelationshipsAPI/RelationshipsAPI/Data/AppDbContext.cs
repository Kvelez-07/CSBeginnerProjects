﻿using Microsoft.EntityFrameworkCore;
using RelationshipsAPI.Models;

namespace RelationshipsAPI.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }
        public DbSet<Character> Characters { get; set; }
        public DbSet<Backpack> Backpacks { get; set; }
    }
}
