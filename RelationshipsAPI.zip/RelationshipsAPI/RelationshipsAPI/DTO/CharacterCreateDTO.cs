﻿namespace RelationshipsAPI.DTO
{
    public record struct CharacterCreateDTO(string Name, BackpackCreateDTO Backpack, List<WeaponCreateDTO> Weapons);
}