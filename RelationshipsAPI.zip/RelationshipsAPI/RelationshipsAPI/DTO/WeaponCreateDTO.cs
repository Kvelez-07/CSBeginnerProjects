﻿namespace RelationshipsAPI.DTO
{
    public record struct WeaponCreateDTO(string Name);
}
