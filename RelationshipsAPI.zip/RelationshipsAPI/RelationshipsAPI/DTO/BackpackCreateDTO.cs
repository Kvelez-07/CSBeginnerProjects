﻿namespace RelationshipsAPI.DTO
{
    public record struct BackpackCreateDTO(string Description);
}