﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RelationshipsAPI.Models
{
    public class Faction
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required, MaxLength(45)]
        public string Name { get; set; } = string.Empty;
        [Required]
        public List<Character> Characters { get; set; } = new List<Character>();
    }
}
