﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace RelationshipsAPI.Models
{
    public class Character
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required, MaxLength(45)]
        public string Name { get; set; } = string.Empty;

        [Required]
        public int BackpackId { get; set; } // Foreign key

        [ForeignKey("BackpackId")]
        public Backpack? Backpack { get; set; } // Navigation property

        [Required]
        public List<Weapon> Weapons { get; set; } = new List<Weapon>(); // Navigation property

        [Required]
        public List<Faction> Factions { get; set; } = new List<Faction>(); // Navigation property
    }
}