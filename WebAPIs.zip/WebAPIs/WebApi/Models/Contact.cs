﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApi.Models
{
    public class Contact
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required, MaxLength(45)]
        public string FirstName { get; set; } = string.Empty;
        [Required, MaxLength(45)]
        public string LastName { get; set; } = string.Empty;
        [Required]
        public DateTime BirthDate { get; set; } = DateTime.UtcNow;
    }
}
