﻿using Microsoft.EntityFrameworkCore;
using SSMSMinAPI.Data;
using SSMSMinAPI.Models;

namespace SSMSMinAPI.Controllers
{
    public static class BooksController
    {
        public static void MapBookEndpoints(this IEndpointRouteBuilder routes)
        {
            routes.MapGet("/api/v1/books", async (AppDbContext context) =>
            {
                return await context.Books.ToListAsync();
            });

            routes.MapGet("/api/v1/books/{id}", async (int id, AppDbContext context) =>
            {
                var book = await context.Books.FindAsync(id);
                return book is not null ? Results.Ok(book) : Results.NotFound();
            });

            routes.MapPost("/api/v1/books", async (Book book, AppDbContext context) =>
            {
                context.Books.Add(book);
                await context.SaveChangesAsync();
                return Results.Created($"/api/v1/books/{book.Id}", book);
            });

            routes.MapPut("/api/v1/books/{id}", async (int id, Book updatedBook, AppDbContext context) =>
            {
                var book = await context.Books.FindAsync(id);
                if (book is null)
                    return Results.NotFound();

                book.Title = updatedBook.Title;
                book.Author = updatedBook.Author;

                await context.SaveChangesAsync();
                return Results.Ok(book);
            });

            routes.MapDelete("/api/v1/books/{id}", async (int id, AppDbContext context) =>
            {
                var book = await context.Books.FindAsync(id);
                if (book is null)
                    return Results.NotFound();

                context.Books.Remove(book);
                await context.SaveChangesAsync();
                return Results.Ok(book);
            });
        }
    }
}
