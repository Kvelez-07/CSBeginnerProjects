﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SSMSMinAPI.Data;
using SSMSMinAPI.Dtos;
using SSMSMinAPI.Models;

namespace SSMSMinAPI.Controllers
{
    public static class HeroesController
    {
        public static void MapHeroEndpoints(this IEndpointRouteBuilder routes)
        {
            var group = routes.MapGroup("/api/heroes");

            // GET: api/heroes
            group.MapGet("/", async ([FromServices] AppDbContext db, [FromServices] IMapper mapper) =>
            {
                var heroes = await db.Heroes.ToListAsync();
                var heroesDto = mapper.Map<IEnumerable<HeroDto>>(heroes);
                return Results.Ok(heroesDto);
            });

            // GET: api/heroes/{id}
            group.MapGet("/{id:int}", async (int id, [FromServices] AppDbContext db, [FromServices] IMapper mapper) =>
            {
                var hero = await db.Heroes.FindAsync(id);
                if (hero == null)
                {
                    return Results.NotFound();
                }

                var heroDto = mapper.Map<HeroDto>(hero);
                return Results.Ok(heroDto);
            });

            // POST: api/heroes
            group.MapPost("/", async ([FromBody] HeroDto heroDto, [FromServices] AppDbContext db, [FromServices] IMapper mapper) =>
            {
                var hero = mapper.Map<Hero>(heroDto);
                db.Heroes.Add(hero);
                await db.SaveChangesAsync();

                var createdHeroDto = mapper.Map<HeroDto>(hero);
                return Results.Created($"/api/heroes/{hero.Id}", createdHeroDto);
            });

            // PUT: api/heroes/{id}
            group.MapPut("/{id:int}", async (int id, [FromBody] HeroDto heroDto, [FromServices] AppDbContext db, [FromServices] IMapper mapper) =>
            {
                var existingHero = await db.Heroes.FindAsync(id);
                if (existingHero == null)
                {
                    return Results.NotFound();
                }

                mapper.Map(heroDto, existingHero);
                existingHero.DateUpdated = DateTime.UtcNow;

                db.Entry(existingHero).State = EntityState.Modified;
                await db.SaveChangesAsync();

                return Results.NoContent();
            });

            // DELETE: api/heroes/{id}
            group.MapDelete("/{id:int}", async (int id, [FromServices] AppDbContext db) =>
            {
                var hero = await db.Heroes.FindAsync(id);
                if (hero == null)
                {
                    return Results.NotFound();
                }

                db.Heroes.Remove(hero);
                await db.SaveChangesAsync();

                return Results.NoContent();
            });
        }
    }
}
