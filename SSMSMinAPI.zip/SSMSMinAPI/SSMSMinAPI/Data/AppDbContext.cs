﻿using Microsoft.EntityFrameworkCore;
using SSMSMinAPI.Models;

namespace SSMSMinAPI.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<Book> Books { get; set; }
        public DbSet<Hero> Heroes { get; set; }
    }
}
