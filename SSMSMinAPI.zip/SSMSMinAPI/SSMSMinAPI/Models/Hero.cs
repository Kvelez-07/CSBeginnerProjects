﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SSMSMinAPI.Models
{
    public class Hero
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required, MaxLength(100)]
        public string Name { get; set; } = string.Empty;
        [Required, MaxLength(100)]
        public string FirstName { get; set; } = string.Empty;
        [Required, MaxLength(100)]
        public string LastName { get; set; } = string.Empty;
        [Required, MaxLength(100)]
        public string Place { get; set; } = string.Empty;
        [Required]
        public DateTime DateAdded { get; set; }
        [Required]
        public DateTime? DateUpdated { get; set; }
    }
}
