﻿using AutoMapper;
using SSMSMinAPI.Dtos;
using SSMSMinAPI.Models;

namespace SSMSMinAPI.Profiles
{
    public class HeroProfile : Profile
    {
        public HeroProfile()
        {
            CreateMap<Hero, HeroDto>()
                .ForMember(dest => dest.Name, src => src.MapFrom(h => h.Name))
                .ForMember(dest => dest.FirstName, src => src.MapFrom(h => h.FirstName))
                .ForMember(dest => dest.LastName, src => src.MapFrom(h => h.LastName))
                .ForMember(dest => dest.Place, src => src.MapFrom(h => h.Place));

            CreateMap<HeroDto, Hero>()
                .ForMember(dest => dest.Id, src => src.Ignore())
                .ForMember(dest => dest.Name, src => src.MapFrom(h => h.Name))
                .ForMember(dest => dest.FirstName, src => src.MapFrom(h => h.FirstName))
                .ForMember(dest => dest.LastName, src => src.MapFrom(h => h.LastName))
                .ForMember(dest => dest.Place, src => src.MapFrom(h => h.Place))
                .ForMember(dest => dest.DateAdded, src => src.MapFrom(h => DateTime.UtcNow))
                .ForMember(dest => dest.DateUpdated, src => src.MapFrom(h => DateTime.UtcNow));
        }
    }
}
