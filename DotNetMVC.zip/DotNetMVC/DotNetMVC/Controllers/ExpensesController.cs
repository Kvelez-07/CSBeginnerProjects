﻿using Microsoft.AspNetCore.Mvc;
using DotNetMVC.Models; // Import your models
using DotNetMVC.Data;
using Microsoft.EntityFrameworkCore; // Assuming you are using an AppDbContext to interact with the database

namespace DotNetMVC.Controllers
{
    public class ExpensesController : Controller
    {
        private readonly AppDbContext _context; // Dependency injection for your DbContext

        public ExpensesController(AppDbContext context)
        {
            _context = context;
        }

        // Index action to display the list of expenses
        public async Task<IActionResult> Index()
        {
            var expenses = await _context.Expenses.ToListAsync();
            return View(expenses);
        }

        // Create action to display and handle the create form
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Expense expense)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Add(expense);
                    await _context.SaveChangesAsync();
                    TempData["SuccessMessage"] = "Expense created successfully.";
                    return RedirectToAction(nameof(Index)); // Redirect to index after creation
                }
                catch (Exception ex)
                {
                    TempData["ErrorMessage"] = "Error creating expense: " + ex.Message;
                }
            }
            // If we got this far, something failed, redisplay form
            return View(expense);
        }

        // Edit action to display and handle the edit form
        public async Task<IActionResult> Edit(int id)
        {
            var expense = await _context.Expenses.FindAsync(id);
            if (expense == null)
            {
                return NotFound();
            }
            return View(expense);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(Expense expense)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(expense);
                    await _context.SaveChangesAsync();
                    TempData["SuccessMessage"] = "Expense updated successfully.";
                    return RedirectToAction(nameof(Index)); // Redirect to index after update
                }
                catch (Exception ex)
                {
                    TempData["ErrorMessage"] = "Error updating expense: " + ex.Message;
                }
            }
            // If we got this far, something failed, redisplay form
            return View(expense);
        }

        // Delete action to display the confirmation page
        public async Task<IActionResult> Delete(int id)
        {
            var expense = await _context.Expenses.FindAsync(id);
            if (expense == null)
            {
                return NotFound();
            }
            return View(expense);
        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var expense = await _context.Expenses.FindAsync(id);
            if (expense != null)
            {
                try
                {
                    _context.Expenses.Remove(expense);
                    await _context.SaveChangesAsync();
                    TempData["SuccessMessage"] = "Expense deleted successfully.";
                }
                catch (Exception ex)
                {
                    TempData["ErrorMessage"] = "Error deleting expense: " + ex.Message;
                }
            }
            return RedirectToAction(nameof(Index));
        }

        // Details action to display expense details
        public async Task<IActionResult> Details(int id)
        {
            var expense = await _context.Expenses.FindAsync(id);
            if (expense == null)
            {
                return NotFound();
            }
            return View(expense);
        }
    }
}
