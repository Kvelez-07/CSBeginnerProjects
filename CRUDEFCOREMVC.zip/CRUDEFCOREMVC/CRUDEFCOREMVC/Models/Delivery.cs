﻿using System;
using System.Collections.Generic;

namespace CRUDEFCOREMVC.Models;

public partial class Delivery
{
    public int DeliveryId { get; set; }

    public string Description { get; set; } = null!;

    public DateOnly? DeliveryDate { get; set; }

    public int ClientId { get; set; }

    public virtual Client Client { get; set; } = null!;
}
