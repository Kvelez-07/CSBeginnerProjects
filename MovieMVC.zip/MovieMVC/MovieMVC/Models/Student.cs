﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MovieMVC.Models
{
    public class Student
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)] // Disable auto-generation of ID for Guid
        public Guid Id { get; set; }

        [Required(ErrorMessage = "Name Required"), MaxLength(45)]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email Required"), MaxLength(100)]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Phone Required"), MaxLength(15)]
        public string Phone { get; set; } = string.Empty;

        [Required]
        public bool Active { get; set; } = true;
    }
}
