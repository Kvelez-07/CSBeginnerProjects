﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MovieMVC.Models
{
    public class User
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required, MaxLength(45)]
        public string Username { get; set; } = string.Empty;
        [Required, StringLength(100, MinimumLength = 6, ErrorMessage = "Password should be at least 6 chars long")]
        public string Password { get; set; } = string.Empty;
        [NotMapped]
        [Required, StringLength(100, MinimumLength = 6, ErrorMessage = "Password should be at least 6 chars long")]
        [Compare(nameof(Password), ErrorMessage = "Passwords do not match")]
        public string ConfirmPassword { get; set; } = string.Empty;
    }
}
