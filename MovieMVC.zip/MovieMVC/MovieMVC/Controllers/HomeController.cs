using Microsoft.AspNetCore.Mvc;
using MovieMVC.Models;
using System.Diagnostics;
using System.Text.Json;

namespace MovieMVC.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            // var user = HttpContext.Session.GetObject<User>("currentUser");
            // var user = JsonSerializer.Deserialize<User>(Request.Cookies["currentUser"]!) ?? new User();
            ViewBag.Username = Request.Cookies["currentUser"];
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
