﻿using Microsoft.AspNetCore.Mvc;
using MovieMVC.Models;
using System.Text.Json;

namespace MovieMVC.Controllers
{
    public class UsersController : Controller
    {
        public async Task<IActionResult> Login() => await Task.Run(() => View());

        [HttpPost]
        public IActionResult Login(User u)
        {
            // HttpContext.Session.SetObject("currentUser", u);
            // Response.Cookies.Append("currentUser", JsonSerializer.Serialize(u));
            var options = new CookieOptions { Expires = DateTime.Now.AddDays(10) };
            Response.Cookies.Append("currentUser", JsonSerializer.Serialize(u), options); // persist for 10 minutes
            return RedirectToAction(nameof(Index), "Home");
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Remove("currentUser");
            return RedirectToAction(nameof(Index), "Home");
        }
    }
}
