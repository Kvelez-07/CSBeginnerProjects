﻿using DemoMVC.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DemoMVC.Controllers
{
    public class FAQsController : Controller
    {
        private readonly AppDbContext _context;

        public FAQsController(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var faqs = await _context.FAQs.Include(f => f.Category).Include(f => f.Topic).ToListAsync();
            return View(faqs);
        }
    }
}
