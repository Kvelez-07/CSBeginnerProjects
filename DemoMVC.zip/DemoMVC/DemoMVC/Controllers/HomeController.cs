using DemoMVC.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace DemoMVC.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IActionResult Index()
        {
            ViewBag.Username = "Kvelez07";
            ViewBag.Salary = 1000;
            ViewData["Job"] = "Software Developer";

            return View(new FutureValue());
        }

        [HttpPost]
        public IActionResult Index(FutureValue futureValue)
        {
            ViewBag.Username = "Kvelez07";
            ViewBag.Salary = 1000;
            ViewData["Job"] = "Software Developer";

            if (ModelState.IsValid)
            {
                ViewBag.FutureValue = futureValue.CalculateFutureValue();
                ViewBag.SuccessMessage = "Calculation successful!";
            }
            else
            {
                ViewBag.ErrorMessage = "Calculation failed. Please correct the errors and try again.";
            }

            return View(futureValue);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
