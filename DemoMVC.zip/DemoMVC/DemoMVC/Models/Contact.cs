﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DemoMVC.Models
{
    public class Contact
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required(ErrorMessage = "Enter FirstName")]
        [RegularExpression(@"^[A-Z]+[a-zA-Z""'\s-]*$", ErrorMessage = "Avoid special characters.")]
        public string FirstName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Enter LastName")]
        [RegularExpression(@"^[A-Z]+[a-zA-Z""'\s-]*$", ErrorMessage = "Avoid special characters.")]
        public string LastName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Enter Phone")]
        public string Phone { get; set; } = string.Empty;

        [Required]
        public int CategoryId { get; set; }

        // Navigation property
        [ValidateNever]
        public Category Category { get; set; } = new();

        [Required]
        public DateTime DateAdded { get; set; } = DateTime.Now;
    }
}
