﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DemoMVC.Models
{
    public class FAQ
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string Question { get; set; } = string.Empty;

        [Required, MaxLength(300)]
        public string Answer { get; set; } = string.Empty;

        [Required]
        public int CategoryId { get; set; }
        public Category Category { get; set; } = new();

        [Required]
        public int TopicId { get; set; }
        public Topic Topic { get; set; } = new();
    }
}
