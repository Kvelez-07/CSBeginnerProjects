﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DemoMVC.Models.Configuration
{
    public class DayConfig : IEntityTypeConfiguration<Day>
    {
        public void Configure(EntityTypeBuilder<Day> builder)
        {
            builder.HasData(
                new Day { Id = 1, Name = "Monday" },
                new Day { Id = 2, Name = "Tuesday" },
                new Day { Id = 3, Name = "Wednesday" },
                new Day { Id = 4, Name = "Thursday" },
                new Day { Id = 5, Name = "Friday" }
            );
        }
    }
}
