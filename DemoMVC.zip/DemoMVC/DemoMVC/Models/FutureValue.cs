﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DemoMVC.Models
{
    public class FutureValue
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required, Column(TypeName = "decimal(10,2)")]
        [Display(Name = "Monthly Investment")]
        [Range(1, 5000, ErrorMessage = "Monthly Investment must be between $1 and $5000.")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal MonthlyInvestment { get; set; }

        [Required]
        [Range(1, 50, ErrorMessage = "Years must be between 1 and 50.")]
        public int Years { get; set; }

        [Required, Column(TypeName = "decimal(5,2)")]
        [Display(Name = "Yearly Interest Rate (%)")]
        [Range(0.1, 10.0, ErrorMessage = "Interest Rate must be between 0.1% and 10.0%.")]
        public decimal InterestRate { get; set; }

        public decimal CalculateFutureValue()
        {
            int months = Years * 12;
            decimal monthlyInterestRate = InterestRate / 100 / 12; // Convert annual rate to monthly decimal rate
            decimal futureValue = 0;

            for (int i = 0; i < months; i++)
            {
                futureValue = (futureValue + MonthlyInvestment) * (1 + monthlyInterestRate);
            }

            return futureValue;
        }
    }
}
