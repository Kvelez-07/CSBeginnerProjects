﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DemoMVC.Models
{
    public class Class
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required, MaxLength(50)]
        public string Title { get; set; } = string.Empty;

        [Required, MaxLength(50)]
        [Range(100, 500)]
        public int Number { get; set; }

        [Required, Display(Name = "Time")]
        [RegularExpression(@"^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$")]
        [StringLength(4, MinimumLength = 4)]
        public string MilitaryTime { get; set; } = string.Empty;

        [Required]
        public int TeacherId { get; set; } // FK
        
        [ValidateNever]
        public Teacher Teacher { get; set; } = new();

        [Required]
        public int DayId { get; set; }

        [ValidateNever]
        public Day Day { get; set; } = new();
    }
}