﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DemoMVC.Models
{
    public class Movie
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required(ErrorMessage = "Enter a name")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Enter year of release")]
        [Range(1900, 2030)]
        public int Year { get; set; }

        [Required(ErrorMessage = "Enter stars rating")]
        [Range(1, 5)]
        public int Rating { get; set; }
    }
}
