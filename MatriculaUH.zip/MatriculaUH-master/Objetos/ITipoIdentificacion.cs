﻿namespace Objetos
{
    public enum ITipoIdentificacion
    {
        Cedula,
        Pasaporte,
        CarnetResidente
    }
}
