﻿namespace Objetos
{
    public class oCarrera
    {
        public int IdCarrera { get; set; }
        public string Carrera { get; set; }
        public bool Estado { get; set; }
    }
}
