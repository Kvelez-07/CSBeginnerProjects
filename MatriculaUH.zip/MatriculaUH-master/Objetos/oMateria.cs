namespace Objetos
{
    public class oMateria
    {
        public oCarrera Carrera { get; set; } // Get IdCarrera and Carrera
        public int IdMateria { get; set; }
        public string Materia { get; set; }
        public int Creditos { get; set; }
    }
}
