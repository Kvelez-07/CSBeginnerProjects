﻿namespace Objetos
{
    public enum IHorario
    {
        Lunes,
        Martes,
        Miercoles,
        Jueves,
        Viernes,
        Sabado
        // No hay clases los domingos
    }
}
