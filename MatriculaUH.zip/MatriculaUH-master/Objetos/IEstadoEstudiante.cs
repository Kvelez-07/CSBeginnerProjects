﻿namespace Objetos
{
    public enum IEstadoEstudiante
    {
        Activo,
        Inactivo,
        Graduado,
        Matriculado
    }
}
