﻿using System;

namespace Objetos
{
    public class oEstudiante
    {
        public string IdEstudiante { get; set; }
        public string Nombre { get; set; }
        public string ApellidoPaterno { get; set; }
        public string ApellidoMaterno { get; set; }
        public int Identificacion { get; set; } // Numero de Cedual, Pasaporte, CarnetResidente
        public oCarrera Carrera { get; set; } // Objeto Carrera
        public DateTime FechaNacimiento { get; set; } // GetDate() en SQL
        public DateTime FechaIngreso { get; set; } // GetDate() en SQL
        public IEstadoEstudiante Estado { get; set; } // Enum
        public ITipoIdentificacion TipoIdentificacion { get; set; } // Enum
    }
}
