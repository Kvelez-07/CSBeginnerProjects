﻿namespace Objetos
{
    public class oMatricula
    {
        public int IdMatricula { get; set; }
        public oEstudiante IdEstudiante { get; set; }
        public oGrupo IdGrupo { get; set; }
    }
}
