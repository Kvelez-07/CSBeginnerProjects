﻿namespace Objetos
{
    public class oGrupo
    {
        public int IdGrupo { get; set; }
        public oMateria Materia { get; set; } // Objeto Materia
        public int NumeroGrupo { get; set; }
        public IHorario Horario { get; set; } // Enum
        public int Cupo { get; set; }
        public IEstadoGrupo Estado { get; set; } // Enum
    }
}
