﻿namespace Objetos
{
    public enum IEstadoGrupo
    {
        Abierto,
        Cerrado
    }
}
