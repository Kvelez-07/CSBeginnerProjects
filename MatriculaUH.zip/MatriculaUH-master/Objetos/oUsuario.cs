﻿namespace Objetos
{
    public class oUsuario
    {
        public string usuario { get; set; }
        public int idRol { get; set; }
        public string Rol { get; set; }
        
        //Agregar los atributos del usuario que hacen falta
    }
}
