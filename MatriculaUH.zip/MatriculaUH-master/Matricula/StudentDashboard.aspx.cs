﻿using System;
using System.Web;

namespace Matricula
{
    public partial class StudentDashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Prevent caching of the page
            Response.Cache.SetExpires(DateTime.UtcNow.AddDays(-1));
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();

            if (Session["studentUser"] == null)
            {
                // Redirect to login page if the session is null
                Response.Redirect("Login.aspx");
            }
        }

        protected void btnMatricula_Click(object sender, EventArgs e)
        {
            Response.Redirect("ManejoMatricula.aspx");
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            // Clear session and any other relevant user data
            Session["studentUser"] = null;
            Session.Abandon(); // Abandon the session to clear any remaining session data
            Response.Cookies.Add(new HttpCookie("ASP.NET_SessionId", ""));
            Response.Redirect("Login.aspx");
        }
    }
}