﻿using System;
using System.Web;

namespace Matricula
{
    public partial class AdminDashboard : System.Web.UI.Page
    {
        private Logica.LnEstudiante logica = new Logica.LnEstudiante();

        protected void Page_Load(object sender, EventArgs e)
        {
            // Prevent caching of the page
            Response.Cache.SetExpires(DateTime.UtcNow.AddDays(-1));
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();

            if (Session["adminUser"] == null)
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void btnStudentManagement_Click(object sender, EventArgs e)
        {
            Response.Redirect("ManejoEstudiantes.aspx");
        }

        protected void btnCarreras_Click(object sender, EventArgs e)
        {
            Response.Redirect("Carreras.aspx");
        }

        protected void btnSubjectManagement_Click(object sender, EventArgs e)
        {
            Response.Redirect("ManejoMaterias.aspx");
        }

        protected void btnGroupManagement_Click(object sender, EventArgs e)
        {
            Response.Redirect("ManejoGrupos.aspx");
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            // Clear session and any other relevant user data
            Session["adminUser"] = null;
            Session.Abandon(); // Abandon the session to clear any remaining session data
            Response.Cookies.Add(new HttpCookie("ASP.NET_SessionId", ""));
            Response.Redirect("Login.aspx");
        }
    }
}