using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Datos
{
    public class LdCarreras
    {
        private SqlConnection _connection;

        public LdCarreras()
        {
            InitConnection();
        }

        private void InitConnection()
        {
            _connection = new SqlConnection();
            _connection.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
        }

        public DataTable ConsultaCarreras(int idCarrera)
        {
            SqlCommand cmdEjecutar = new SqlCommand
            {
                CommandText = "[dbo].[spSeleccionaCarreras]",
                CommandType = CommandType.StoredProcedure,
                Connection = _connection
            };

            cmdEjecutar.Parameters.AddWithValue("@idCarrera", idCarrera == 0 ? (object)DBNull.Value : idCarrera);

            DataTable resultado = new DataTable("Carreras");
            SqlDataAdapter adapter = new SqlDataAdapter(cmdEjecutar);

            try
            {
                _connection.Open();
                adapter.Fill(resultado);
                return resultado;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (_connection.State == ConnectionState.Open)
                {
                    _connection.Close();
                }
                cmdEjecutar.Dispose();
            }
        }

        public int InsertarCarrera(string nombreCarrera)
        {
            SqlCommand cmdEjecutar = new SqlCommand
            {
                CommandText = "[dbo].[spInsertaCarrera]",
                CommandType = CommandType.StoredProcedure,
                Connection = _connection
            };

            cmdEjecutar.Parameters.AddWithValue("@nombre", nombreCarrera);
            cmdEjecutar.Parameters.Add("@cod_error", SqlDbType.Int, 4).Direction = ParameterDirection.Output;
            cmdEjecutar.Parameters.Add("@msg_error", SqlDbType.VarChar, 256).Direction = ParameterDirection.Output;
            cmdEjecutar.Parameters.Add("@idCarrera", SqlDbType.Int, 4).Direction = ParameterDirection.Output;

            try
            {
                _connection.Open();
                cmdEjecutar.ExecuteNonQuery();

                int cod_error = Int32.Parse(cmdEjecutar.Parameters["@cod_error"].Value.ToString());
                string msg_error = cmdEjecutar.Parameters["@msg_error"].Value.ToString();
                int idFactura = Int32.Parse(cmdEjecutar.Parameters["@idCarrera"].Value.ToString());

                if (cod_error != 0)
                {
                    throw new Exception("Ocurrió un error: " + msg_error);
                }

                return idFactura;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (_connection.State == ConnectionState.Open)
                {
                    _connection.Close();
                }
                cmdEjecutar.Dispose();
            }
        }

        public int ObtenerCantidadEstudiantes(int idCarrera)
        {
            SqlCommand cmdEjecutar = new SqlCommand
            {
                CommandText = "[dbo].[spObtenerCantidadEstudiantes]",
                CommandType = CommandType.StoredProcedure,
                Connection = _connection
            };

            cmdEjecutar.Parameters.AddWithValue("@idCarrera", idCarrera);

            try
            {
                _connection.Open();
                return (int)cmdEjecutar.ExecuteScalar();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (_connection.State == ConnectionState.Open)
                {
                    _connection.Close();
                }
                cmdEjecutar.Dispose();
            }
        }

        public int ObtenerCantidadMaterias(int idCarrera)
        {
            SqlCommand cmdEjecutar = new SqlCommand
            {
                CommandText = "[dbo].[spObtenerCantidadMaterias]",
                CommandType = CommandType.StoredProcedure,
                Connection = _connection
            };

            cmdEjecutar.Parameters.AddWithValue("@idCarrera", idCarrera);

            try
            {
                _connection.Open();
                return (int)cmdEjecutar.ExecuteScalar();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (_connection.State == ConnectionState.Open)
                {
                    _connection.Close();
                }
                cmdEjecutar.Dispose();
            }
        }

        public void ActualizarCarrera(string nombreCarrera, int idCarrera)
        {
            SqlCommand cmdEjecutar = new SqlCommand
            {
                CommandText = "[dbo].[spActualizarCarrera]",
                CommandType = CommandType.StoredProcedure,
                Connection = _connection
            };

            cmdEjecutar.Parameters.AddWithValue("@idCarrera", idCarrera);
            cmdEjecutar.Parameters.AddWithValue("@nombre", nombreCarrera);
            cmdEjecutar.Parameters.AddWithValue("@estado", 1);
            cmdEjecutar.Parameters.Add("@cod_error", SqlDbType.Int, 4).Direction = ParameterDirection.Output;
            cmdEjecutar.Parameters.Add("@msg_error", SqlDbType.VarChar, 256).Direction = ParameterDirection.Output;

            try
            {
                _connection.Open();
                cmdEjecutar.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (_connection.State == ConnectionState.Open)
                {
                    _connection.Close();
                }
                cmdEjecutar.Dispose();
            }
        }
    }
}
