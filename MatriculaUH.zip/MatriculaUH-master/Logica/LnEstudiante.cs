﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Objetos;

namespace Logica
{
    public class LnEstudiante
    {
        private Datos.LdEstudiante datos = new Datos.LdEstudiante();

        public List<oEstudiante> BuscarEstudiantes(int? idEstudiante, string nombre, string apellidoPaterno, string apellidoMaterno, int? identificacion, int? idEstadoEstudiante, int? idTipoIdentificacion, int? idCarrera)
        {
            try
            {
                var tabla = datos.BuscarEstudiantes(idEstudiante, nombre, apellidoPaterno, apellidoMaterno, identificacion, idEstadoEstudiante, idTipoIdentificacion, idCarrera);

                List<oEstudiante> listado = tabla.AsEnumerable()
                    .Select(row => new oEstudiante
                    {
                        IdEstudiante = row.Field<int>("IdEstudiante").ToString(),
                        Nombre = row.Field<string>("Nombre"),
                        ApellidoPaterno = row.Field<string>("ApellidoPaterno"),
                        ApellidoMaterno = row.Field<string>("ApellidoMaterno"),
                        Identificacion = row.Field<int>("Identificacion"),
                        FechaNacimiento = row.Field<DateTime>("FechaNacimiento"),
                        FechaIngreso = row.Field<DateTime>("FechaIngreso"),
                        Estado = (IEstadoEstudiante)row.Field<int>("IdEstadoEstudiante"),
                        TipoIdentificacion = (ITipoIdentificacion)row.Field<int>("IdTipoIdentificacion"),
                        Carrera = new oCarrera { IdCarrera = row.Field<int>("IdCarrera") }
                    })
                    .ToList();

                return listado;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<oEstudiante> ListarEstudiantes()
        {
            try
            {
                var tabla = datos.ListarEstudiantes();
                List<oEstudiante> listado = tabla.AsEnumerable()
                    .Select(row => new oEstudiante
                    {
                        IdEstudiante = row.Field<int>("IdEstudiante").ToString(),
                        Nombre = row.Field<string>("Nombre"),
                        ApellidoPaterno = row.Field<string>("ApellidoPaterno"),
                        ApellidoMaterno = row.Field<string>("ApellidoMaterno"),
                        Identificacion = row.Field<int>("Identificacion"),
                        FechaNacimiento = row.Field<DateTime>("FechaNacimiento"),
                        FechaIngreso = row.Field<DateTime>("FechaIngreso"),
                        Estado = (IEstadoEstudiante)row.Field<int>("IdEstadoEstudiante"),
                        TipoIdentificacion = (ITipoIdentificacion)row.Field<int>("IdTipoIdentificacion"),
                        Carrera = new oCarrera { IdCarrera = row.Field<int>("IdCarrera") }
                    })
                    .ToList();

                return listado;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public oEstudiante BuscarEstudiantePorId(int idEstudiante)
        {
            try
            {
                var tabla = datos.BuscarEstudiantePorId(idEstudiante);

                var estudiante = tabla.AsEnumerable()
                    .Select(row => new oEstudiante
                    {
                        IdEstudiante = row.Field<int>("IdEstudiante").ToString(),
                        Nombre = row.Field<string>("Nombre"),
                        ApellidoPaterno = row.Field<string>("ApellidoPaterno"),
                        ApellidoMaterno = row.Field<string>("ApellidoMaterno"),
                        Identificacion = row.Field<int>("Identificacion"),
                        FechaNacimiento = row.Field<DateTime>("FechaNacimiento"),
                        FechaIngreso = row.Field<DateTime>("FechaIngreso"),
                        Estado = (IEstadoEstudiante)row.Field<int>("IdEstadoEstudiante"),
                        TipoIdentificacion = (ITipoIdentificacion)row.Field<int>("IdTipoIdentificacion"),
                        Carrera = new oCarrera { IdCarrera = row.Field<int>("IdCarrera") }
                    })
                    .FirstOrDefault();

                return estudiante;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public bool CrearEstudiante(string nombre, string apellidoPaterno, string apellidoMaterno, int identificacion, DateTime fechaNacimiento, DateTime fechaIngreso, int idEstadoEstudiante, int idTipoIdentificacion, int idCarrera, out int idEstudiante)
        {
            try
            {
                int codError;
                string msgError;
                idEstudiante = datos.CrearEstudiante(nombre, apellidoPaterno, apellidoMaterno, identificacion, fechaNacimiento, fechaIngreso, idEstadoEstudiante, idTipoIdentificacion, idCarrera, out codError, out msgError);

                if (codError != 0)
                {
                    throw new Exception("Error creating student: " + msgError);
                }

                return true;
            }
            catch (Exception ex)
            {
                idEstudiante = -1; // or handle appropriately
                throw new Exception(ex.Message);
            }
        }
    }
}
