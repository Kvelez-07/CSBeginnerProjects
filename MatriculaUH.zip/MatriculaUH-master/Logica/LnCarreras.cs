using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Objetos;
using Datos;

namespace Logica
{
    public class LnCarreras
    {
        public List<oCarrera> ConsultaCarreras(int idCarrera)
        {
            try
            {
                LdCarreras datos = new LdCarreras();
                DataTable tabla = datos.ConsultaCarreras(idCarrera);

                return tabla.AsEnumerable()
                    .Select(row => new oCarrera
                    {
                        IdCarrera = row.Field<int>("IdCarrera"),
                        Carrera = row.Field<string>("Carrera"),
                        Estado = row.Field<bool>("Estado")
                    })
                    .ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public bool InsertarCarrera(string nombreCarrera)
        {
            try
            {
                if (string.IsNullOrEmpty(nombreCarrera))
                {
                    throw new Exception("La carrera no debe ser vacía.");
                }

                LdCarreras datos = new LdCarreras();
                int idCarrera = datos.InsertarCarrera(nombreCarrera);

                return idCarrera > 0;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public int ObtenerCantidadEstudiantes(int idCarrera)
        {
            LdCarreras datos = new LdCarreras();
            return datos.ObtenerCantidadEstudiantes(idCarrera);
        }

        public int ObtenerCantidadMaterias(int idCarrera)
        {
            LdCarreras datos = new LdCarreras();
            return datos.ObtenerCantidadMaterias(idCarrera);
        }

        public void ActualizarCarrera(oCarrera carrera)
        {
            try
            {
                if (string.IsNullOrEmpty(carrera.Carrera))
                {
                    throw new Exception("El nombre de la carrera no debe ser vacío.");
                }

                LdCarreras datos = new LdCarreras();
                datos.ActualizarCarrera(carrera.Carrera, carrera.IdCarrera);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
