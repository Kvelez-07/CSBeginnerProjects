﻿using System.ComponentModel.DataAnnotations;

namespace NewApi.DTO
{
    public class BookDTO
    {
        [Required, MaxLength(50)]
        public string Title { get; set; } = null!;

        [Required, MaxLength(50)]
        public string Author { get; set; } = null!;

        [Required]
        [Range(1000, 2100, ErrorMessage = "Year must be between 1000 and 2100.")]
        public int YearPublishing { get; set; }
    }
}
