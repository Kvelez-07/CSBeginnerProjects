﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NewApi.Models
{
    public class Book
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required, MaxLength(50)]
        public string Title { get; set; } = null!;

        [Required, MaxLength(50)]
        public string Author { get; set; } = null!;

        [Required]
        [Range(1000, 2100, ErrorMessage = "Year must be between 1000 and 2100.")]
        public int YearPublishing { get; set; }
    }
}
