using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using PolicyAuthAPI.Data;
using System.Text;
using Microsoft.OpenApi.Models;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using Microsoft.AspNetCore.Authorization;
using PolicyAuthAPI.Models;
using PolicyAuthAPI.CustomRequirement;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Add the DbContext with SQL Server
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Add Identity services
builder.Services.AddIdentity<IdentityUser, IdentityRole>()
    .AddEntityFrameworkStores<AppDbContext>()
    .AddSignInManager()
    .AddRoles<IdentityRole>();

// Configure JWT authentication
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
}).AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = builder.Configuration["Jwt:Issuer"],
        ValidAudience = builder.Configuration["Jwt:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]!))
    };
});

builder.Services.AddSwaggerGen(swagger =>
{
    swagger.SwaggerDoc("v1", new OpenApiInfo { Version = "v1", Title = "My API" });
    swagger.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme()
    {
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
    });

    swagger.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });
});

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("AdminManagerUserPolicy", policy =>
    {
        policy.RequireAuthenticatedUser();
        policy.RequireRole("Admin", "Manager", "User");
    });
    options.AddPolicy("AdminManagerPolicy", policy =>
    {
        policy.RequireAuthenticatedUser();
        policy.RequireRole("Admin", "Manager");
    });
    options.AddPolicy("AdminUserPolicy", policy =>
    {
        policy.RequireAuthenticatedUser();
        policy.RequireRole("Admin", "User");
        policy.Requirements.Add(new MinimumAgeRequirement(18));
    });
});

builder.Services.AddSingleton<IAuthorizationHandler, MinimumAgeHandler>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// Apply authentication and authorization middleware
app.UseAuthentication();
app.UseAuthorization();

// Create an account
app.MapPost("/account/create", async (RegisterModel model, UserManager<AppUser> userManager, ILogger<Program> logger) =>
{
    var user = await userManager.FindByEmailAsync(model.Email);

    if (user != null)
    {
        logger.LogWarning("User with email {Email} already exists.", model.Email);
        return Results.BadRequest("User already exists.");
    }

    var newUser = new AppUser { UserName = model.Email, Email = model.Email, PasswordHash = model.Password, BirthDate = model.BirthDate };
    var result = await userManager.CreateAsync(newUser, model.Password);

    if (!result.Succeeded)
    {
        logger.LogError("Failed to create user: {Errors}", string.Join(", ", result.Errors.Select(e => e.Description)));
        return Results.BadRequest(result.Errors);
    }

    var userClaims = new List<Claim>
    {
        new Claim(ClaimTypes.Email, model.Email),
        new Claim(ClaimTypes.Role, model.Role),
        new Claim(ClaimTypes.DateOfBirth, model.BirthDate.ToString("yyyy-MM-dd"))
    };

    await userManager.AddClaimsAsync(newUser, userClaims);
    logger.LogInformation("User {Email} created successfully.", model.Email);
    return Results.Ok(true);
});

// Login and get JWT
app.MapPost("/account/login", async (string email, string password, UserManager<AppUser> userManager, SignInManager<AppUser> signInManager, IConfiguration config, ILogger<Program> logger) =>
{
    var user = await userManager.FindByEmailAsync(email);
    if (user == null)
    {
        logger.LogWarning("Login failed for {Email}: User not found.", email);
        return Results.NotFound("User not found.");
    }

    var result = await signInManager.CheckPasswordSignInAsync(user, password, false);
    if (!result.Succeeded)
    {
        logger.LogWarning("Login failed for {Email}: Incorrect password.", email);
        return Results.BadRequest("Invalid login attempt.");
    }

    var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config["Jwt:Key"]!));
    var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

    var token = new JwtSecurityToken(
        issuer: config["Jwt:Issuer"],
        audience: config["Jwt:Audience"],
        claims: await userManager.GetClaimsAsync(user),
        expires: DateTime.Now.AddDays(1),
        signingCredentials: credentials
    );

    var tokenString = new JwtSecurityTokenHandler().WriteToken(token);
    logger.LogInformation("User {Email} logged in successfully.", email);
    return Results.Ok(tokenString);
});

app.MapGet("/list", [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Policy = "AdminManagerPolicy")] () =>
{
    return Results.Ok("Only Admin and Manager can access.");
});

app.MapGet("/single", [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Policy = "AdminUserPolicy")] () =>
{
    return Results.Ok("Only Admin and User can access.");
});

app.MapGet("/home", [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Policy = "AdminManagerUserPolicy")] () =>
{
    return Results.Ok("Only Admin, Manager and User can access.");
});

app.Run();
