﻿namespace PolicyAuthAPI.Models
{
    public record struct RegisterModel(string Email, string Role, string Password, DateTime BirthDate);
}
