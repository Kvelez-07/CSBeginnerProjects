﻿using Microsoft.AspNetCore.Identity;

namespace PolicyAuthAPI.Data
{
    public class AppUser : IdentityUser
    {
        public DateTime BirthDate { get; set; }
    }
}
