﻿using Microsoft.AspNetCore.Authorization;

namespace PolicyAuthAPI.CustomRequirement
{
    public class MinimumAgeRequirement (int Age): IAuthorizationRequirement
    {
    }
}