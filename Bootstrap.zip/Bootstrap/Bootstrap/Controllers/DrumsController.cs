﻿using Bootstrap.Models;
using Microsoft.AspNetCore.Mvc;

namespace Bootstrap.Controllers
{
    public class DrumsController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            var drumTotal = new Drum();
            drumTotal.TotalPrice = 0; // Initialize to 0
            return View(drumTotal);
        }

        [HttpPost]
        public IActionResult Index(Drum drum)
        {
            drum.CalculateTotal(); // Calculate total price
            return View(drum); // Return the model with calculated TotalPrice
        }
    }
}
