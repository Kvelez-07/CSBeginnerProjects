﻿using EFCoreRelationships.Data;
using EFCoreRelationships.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EFCoreRelationships.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OneToManyController : ControllerBase
    {
        private readonly AppDbContext _context;

        public OneToManyController(AppDbContext context) => _context = context;

        [HttpGet]
        public async Task<IActionResult> GetBlogs()
        {
            var blogs = await _context.Blogs
                .Include(b => b.Posts)
                .ToListAsync();
            return Ok(blogs);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetBlog(int id)
        {
            var blog = await _context.Blogs
                .Include(b => b.Posts)
                .FirstOrDefaultAsync(b => b.Id == id);
            if (blog == null)
            {
                return NotFound();
            }
            return Ok(blog);
        }

        [HttpPost]
        public async Task<IActionResult> CreateBlog(Blog blog)
        {
            if (blog == null || blog.Posts == null || !blog.Posts.Any())
            {
                return BadRequest("Blog and its Posts cannot be null or empty.");
            }
            _context.Blogs.Add(blog);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetBlog), new { id = blog.Id }, blog);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateBlog(int id, Blog blog)
        {
            if (id != blog.Id || blog.Posts == null || !blog.Posts.Any())
            {
                return BadRequest("Blog ID mismatch or Posts are null/empty.");
            }
            var existingBlog = await _context.Blogs
                .Include(b => b.Posts)
                .FirstOrDefaultAsync(b => b.Id == id);
            if (existingBlog == null)
            {
                return NotFound();
            }
            existingBlog.Titlte = blog.Titlte;
            existingBlog.Posts = blog.Posts; // Update posts
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBlog(int id)
        {
            var blog = await _context.Blogs.FindAsync(id);
            if (blog == null)
            {
                return NotFound();
            }
            _context.Blogs.Remove(blog);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
