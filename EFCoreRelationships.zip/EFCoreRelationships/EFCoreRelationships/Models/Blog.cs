﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EFCoreRelationships.Models
{
    public class Blog
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required, MaxLength(50)]
        public string Titlte { get; set; } = string.Empty;

        public ICollection<Post> Posts { get; set; } = new List<Post>(); // Many-to-One
    }
}
