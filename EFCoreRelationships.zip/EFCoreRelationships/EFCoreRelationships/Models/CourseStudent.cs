﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EFCoreRelationships.Models
{
    public class CourseStudent
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; } // PK of bridge table for M:N relationship

        [Required]
        public int StudentId { get; set; } // Foreign key to Student

        [Required]
        public int CourseId { get; set; } // Foreign key to Course

        [Required]
        public Student Student { get; set; } = new(); // Navigation property to Student

        [Required]
        public Course Course { get; set; } = new(); // Navigation property to Course
    }
}
