﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EFCoreRelationships.Models
{
    public class Post
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string Content { get; set; } = string.Empty;

        [Required]
        public Blog Blog { get; set; } = new();

        [Required]
        public int BlogId { get; set; } // Foreign Key to Blog PK
    }
}
