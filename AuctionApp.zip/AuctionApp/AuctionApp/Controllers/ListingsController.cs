﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AuctionApp.Data;
using AuctionApp.Models;
using AuctionApp.Services;
using System.Drawing;
using System.Security.Claims;

namespace AuctionApp.Controllers
{
    public class ListingsController : Controller
    {
        private readonly IListingService _listingService;
        private readonly IBidService _bidService;
        private readonly ICommentService _commentService;
        private readonly IWebHostEnvironment _webHostEnvService;

        public ListingsController(IListingService listingService, IBidService bidService, ICommentService commentService, IWebHostEnvironment webHostEnvService)
        {
            _listingService = listingService;
            _bidService = bidService;
            _commentService = commentService;
            _webHostEnvService = webHostEnvService;
        }

        // GET: Listings
        public async Task<IActionResult> Index(int? pageNumber, string searchString)
        {
            var applicationDbContext = _listingService.GetAll();
            int pageSize = 3;

            if (!string.IsNullOrEmpty(searchString))
            {
                applicationDbContext = applicationDbContext.Where(l => l.Title.Contains(searchString));
            }
            return View(await PaginatedList<Listing>.CreateAsync(applicationDbContext.Where(l => l.IsSold == false).AsNoTracking(), pageNumber ?? 1, pageSize));
        }

        public async Task<IActionResult> MyListings(int? pageNumber, string searchString)
        {
            var applicationDbContext = _listingService.GetAll();
            int pageSize = 3;
            return View(nameof(Index), await PaginatedList<Listing>.CreateAsync(applicationDbContext.Where(l => l.IdentityUserId == User.FindFirstValue(ClaimTypes.NameIdentifier)).AsNoTracking(), pageNumber ?? 1, pageSize));
        }

        public async Task<IActionResult> MyBids(int? pageNumber, string searchString)
        {
            var applicationDbContext = _bidService.GetAll();
            int pageSize = 3;
            return View(nameof(Index), await PaginatedList<Bid>.CreateAsync(applicationDbContext.Where(b => b.IdentityUserId == User.FindFirstValue(ClaimTypes.NameIdentifier)).AsNoTracking(), pageNumber ?? 1, pageSize));
        }

        // GET: Listings/Create
        public IActionResult Create() => View();

        // POST: Listings/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ListingVM listing)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    // Save the uploaded file to the server
                    string uploadDir = Path.Combine(_webHostEnvService.WebRootPath, "Images");
                    string fileName = Path.GetFileName(listing.Image.FileName);
                    string filePath = Path.Combine(uploadDir, fileName);

                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        await listing.Image.CopyToAsync(fileStream);
                    }

                    // Create the Listing entity with the file path
                    Listing newListing = new()
                    {
                        Title = listing.Title,
                        Description = listing.Description,
                        Price = listing.Price,
                        ImagePath = fileName,
                        IsSold = listing.IsSold,
                        IdentityUserId = listing.IdentityUserId
                    };

                    await _listingService.Add(newListing);
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", $"Unable to create listing: {ex.Message}");
                }
            }
            return View(listing);
        }

        // GET: Listings/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
                return NotFound();

            var listing = await _listingService.GetById(id.Value);

            if (listing == null)
                return NotFound();
            return View(listing);
        }

        [HttpPost]
        public async Task<IActionResult> AddBid([Bind("Id, Price, ListingId, IdentityUserId")] Bid bid)
        {
            if(ModelState.IsValid)
            {
                await _bidService.Add(bid);
            }

            var listing = await _listingService.GetById(bid.ListingId);
            listing.Price = bid.Price;
            await _listingService.SaveChanges();
            return View(nameof(Details), listing);
        }

        public async Task<IActionResult> CloseBiding(int id)
        {
            var listing = await _listingService.GetById(id);
            listing.IsSold = true;
            await _listingService.SaveChanges();
            return View(nameof(Details), listing);
        }

        [HttpPost]
        public async Task<IActionResult> AddComment([Bind("Id, Content, ListingId, IdentityUserId")] Comment comment)
        {
            if (ModelState.IsValid)
            {
                await _commentService.Add(comment);
            }

            var listing = await _listingService.GetById(comment.ListingId);
            return View(nameof(Details), listing);
        }
    }
}
