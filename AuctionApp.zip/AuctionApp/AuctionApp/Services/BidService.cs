﻿using AuctionApp.Data;
using AuctionApp.Models;
using Microsoft.EntityFrameworkCore;

namespace AuctionApp.Services
{
    public class BidService : IBidService
    {
        private readonly AppDbContext _context;

        public BidService(AppDbContext context)
        {
            _context = context;
        }

        public async Task Add(Bid bid)
        {
            _context.Bids.Add(bid);
            await _context.SaveChangesAsync();
        }

        public IQueryable<Bid> GetAll()
        {
            var applicationDbContext = from bid in _context.Bids.Include(l => l.Listing).Include(u => u.User)
                                       select bid;
            return applicationDbContext;
        }
    }
}
