﻿using AuctionApp.Data;
using AuctionApp.Models;
using Microsoft.EntityFrameworkCore;

namespace AuctionApp.Services
{
    public class ListingService : IListingService
    {
        private readonly AppDbContext _context;

        public ListingService(AppDbContext context)
        {
            _context = context;
        }

        public async Task Add(Listing listing)
        {
            await _context.Listings.AddAsync(listing);
            await _context.SaveChangesAsync();
        }

        public IQueryable<Listing> GetAll() => _context.Listings.Include(l => l.User);

        public async Task<Listing> GetById(int id)
        {
            var listing = await _context.Listings
                .Include(l => l.User).
                Include(l => l.Comments).
                Include(l => l.Bids).
                ThenInclude(b => b.User).
                FirstOrDefaultAsync(l => l.Id == id);
            return listing!;
        }

        public async Task SaveChanges()
        {
            await _context.SaveChangesAsync();
        }
    }
}
