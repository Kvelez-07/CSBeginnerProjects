﻿using AuctionApp.Models;

namespace AuctionApp.Services
{
    public interface ICommentService
    {
        Task Add(Comment comment);
    }
}
