﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AuctionApp.Models
{
    public class Listing
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required, MaxLength(45)]
        public string Title { get; set; } = string.Empty;

        [Required, MaxLength(200)]
        public string Description { get; set; } = string.Empty;

        [Required, DataType(DataType.Currency)]
        [Column(TypeName = "decimal(18, 2)")]
        [DisplayFormat(DataFormatString = "{0:C2}")]
        public decimal Price { get; set; }

        [Required, MaxLength(200)]
        public string ImagePath { get; set; } = string.Empty;

        [Required]
        public bool IsSold { get; set; } = false;

        [Required]
        public string IdentityUserId { get; set; } = string.Empty;

        [ForeignKey(nameof(IdentityUserId))]
        public IdentityUser User { get; set; } = new();

        public List<Bid> Bids { get; set; } = new();
        public List<Comment> Comments { get; set; } = new();
    }
}
