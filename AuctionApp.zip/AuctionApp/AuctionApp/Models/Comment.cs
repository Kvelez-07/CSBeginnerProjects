﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AuctionApp.Models
{
    public class Comment
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required, MaxLength(200)]
        public string Content { get; set; } = string.Empty;

        [Required]
        public string IdentityUserId { get; set; } = string.Empty;

        [ForeignKey(nameof(IdentityUserId))]
        public IdentityUser User { get; set; } = new();

        [Required]
        public int ListingId { get; set; }

        [ForeignKey(nameof(ListingId))]
        public Listing Listing { get; set; } = new();
    }
}