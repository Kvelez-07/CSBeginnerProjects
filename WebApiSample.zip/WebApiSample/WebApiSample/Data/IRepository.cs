﻿using System.Linq.Expressions;

namespace WebApiSample.Data
{
    public interface IRepository<T> where T : class
    {
        Task<IEnumerable<T>> GetAllAsync();
        Task<T> GetByIdAsync(Int64 id);
        Task<T> FindByConditionAsync(Expression<Func<T, bool>> expression);
        void Add(T entity);
        void Update(T entity);
        Task Delete(Int64 id);
        Task<bool> SaveChangesAsync();
    }
}
