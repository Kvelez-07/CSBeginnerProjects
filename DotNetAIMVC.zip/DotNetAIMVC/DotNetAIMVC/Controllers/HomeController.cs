using DotNetAIMVC.Models;
using GroqSharp;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace DotNetAIMVC.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IGroqClient _groqClient;

        public HomeController(ILogger<HomeController> logger, IGroqClient groqClient)
        {
            _logger = logger;
            _groqClient = groqClient;
        }

        public IActionResult Index() => View();

        [HttpPost]
        public async Task<IActionResult> Index(string question)
        {
            question = string.Concat(question, " Please answer with an Axl Rose tone in 100 chars or less.");
            var answer = await _groqClient.CreateChatCompletionAsync(new GroqSharp.Models.Message { Content = question });
            ViewBag.Answer = answer;
            return View();
        }

        public IActionResult Privacy() => View();

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
