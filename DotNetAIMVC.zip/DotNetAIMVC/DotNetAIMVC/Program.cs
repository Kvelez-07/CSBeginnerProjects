using GroqSharp;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

var apiKey = builder.Configuration["ApiKey"];
var apiModel = "llama-3.1-70b-versatile";

builder.Services.AddSingleton<IGroqClient>(sp => new GroqClient(apiKey!, apiModel)
    .SetTemperature(0.5)
    .SetMaxTokens(512)
    .SetTopP(1)
    .SetStop("None")
    .SetStructuredRetryPolicy(5));

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();