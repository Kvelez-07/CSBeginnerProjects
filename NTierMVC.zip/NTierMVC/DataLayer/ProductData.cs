﻿using System.Data.SqlClient;

namespace DataLayer
{
    public class ProductData(string connectionString)
    {
        private readonly string _connectionString = connectionString;

        public List<Product> GetAllProducts()
        {
            List<Product> products = new();

            using (SqlConnection conn = new(_connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new("SELECT * FROM Products", conn))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Product product = new()
                            {
                                Id = reader.GetInt32(0),
                                Name = reader.GetString(1),
                                Price = reader.GetDecimal(2)
                            };
                            products.Add(product);
                        }
                    }
                }
            }
            return products;
        }

        public List<Product> GetProductById(int id)
        {
            List<Product> products = new();

            using (SqlConnection conn = new(_connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new("SELECT * FROM Products WHERE Id = @Id", conn))
                {
                    cmd.Parameters.AddWithValue("@Id", id);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Product product = new()
                            {
                                Id = reader.GetInt32(0),
                                Name = reader.GetString(1),
                                Price = reader.GetDecimal(2)
                            };
                            products.Add(product);
                        }
                    }
                }
            }
            return products;
        }

        public void AddProduct(Product product)
        {
            using (SqlConnection conn = new(_connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new("INSERT INTO Products (Name, Price) VALUES (@Name, @Price)", conn))
                {
                    cmd.Parameters.AddWithValue("@Name", product.Name);
                    cmd.Parameters.AddWithValue("@Price", product.Price);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void UpdateProduct(Product product)
        {
            using (SqlConnection conn = new(_connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new("UPDATE Products SET Name = @Name, Price = @Price WHERE Id = @Id", conn))
                {
                    cmd.Parameters.AddWithValue("@Name", product.Name);
                    cmd.Parameters.AddWithValue("@Price", product.Price);
                    cmd.Parameters.AddWithValue("@Id", product.Id);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void DeleteProduct(int id)
        {
            using (SqlConnection conn = new(_connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new("DELETE FROM Products WHERE Id = @Id", conn))
                {
                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
