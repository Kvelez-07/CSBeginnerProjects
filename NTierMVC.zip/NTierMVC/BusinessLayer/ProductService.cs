﻿using DataLayer;

namespace BusinessLayer
{
    public class ProductService
    {
        private readonly ProductData _productDataAccess;

        public ProductService(string connectionString)
        {
            _productDataAccess = new ProductData(connectionString);
        }

        public List<Product> GetAllProducts()
        {
            return _productDataAccess.GetAllProducts();
        }

        public List<Product> GetProductById(int id)
        {
            return _productDataAccess.GetProductById(id);
        }

        public void AddProduct(Product product)
        {
            _productDataAccess.AddProduct(product);
        }

        public void UpdateProduct(Product product)
        {
            _productDataAccess.UpdateProduct(product);
        }

        public void DeleteProduct(int id)
        {
            _productDataAccess.DeleteProduct(id);
        }
    }
}
